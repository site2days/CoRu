<?php
declare(strict_types=1);

require __DIR__ . '/coru/bootstrap.php';
// чтение конфиг н ачекбокс SLUG
$prettyUrls = (bool)$coru->config->get('site.pretty_urls', false);

if (
    $coru->config->get('site.pretty_urls')
    && isset($_GET['cat'])
    && is_scalar($_GET['cat'])
) {
    $catSlug = trim((string)$_GET['cat'], '/');

    if ($catSlug !== '' && preg_match('/^[a-zA-Z0-9_-]+$/', $catSlug)) {
        header(
            'Location: ' . $coru->url('category/' . rawurlencode($catSlug)),
            true,
            301
        );
        exit;
    }
}

// Старый URL ?p=slug перенаправляем на /slug.
if ($prettyUrls && isset($_GET['p']) && is_scalar($_GET['p'])) {
    $legacyPath = trim((string)$_GET['p'], '/');

    if ($legacyPath !== '' && preg_match('~^[a-zA-Z0-9/_-]+$~', $legacyPath)) {
        header('Location: ' . $coru->url($legacyPath), true, 301);
        exit;
    }
}

$path = $coru->requestPath();
$view = $coru->view();

// Маршруты модулей: goods, chat и другие.
if ($handler = $coru->matchRoute($path)) {
    echo $handler($coru, $path);
    exit;
}

// Категория: ?cat=slug или /category/slug.
$catSlug = $_GET['cat'] ?? null;

if ($catSlug === null && str_starts_with($path, 'category/')) {
    $catSlug = substr($path, strlen('category/'));
}

if ($catSlug !== null) {
    $cat = $coru->categories->get((string)$catSlug);

    if (!$cat) {
        http_response_code(404);
        echo $view->render('404.html.twig', ['path' => $path]);
        exit;
    }

    echo $view->render('category.html.twig', [
        'category' => $cat,
        'pages'    => $coru->pages->byCategory($cat['slug']),
    ]);
    exit;
}

// Главная страница.
if ($path === '' || $path === 'index.php') {
    echo $view->render('home.html.twig', [
        'pages' => $coru->pages->all(true),
    ]);
    exit;
}

// Страница по slug.
$page = $coru->pages->get($path);

if (!$page || empty($page['published'])) {
    http_response_code(404);
    echo $view->render('404.html.twig', ['path' => $path]);
    exit;
}

echo $view->render('page.html.twig', ['page' => $page]);