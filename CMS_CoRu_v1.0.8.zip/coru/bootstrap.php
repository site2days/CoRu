<?php
declare(strict_types=1);

define('CORU_ROOT', dirname(__DIR__));
define('CORU_VERSION', '1.0.8');

require CORU_ROOT . '/coru/Autoload.php';
Coru\Autoload::register();


if (is_file(CORU_ROOT . '/coru/symfony/deprecation-contracts/function.php')) {
    require_once CORU_ROOT . '/coru/symfony/deprecation-contracts/function.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_name('coru_sid');
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'path'     => '/',
    ]);
    session_start();
}

$coru = Coru\App::instance();
/// глобальная функция перевода
if (!function_exists('mt')) {
    function mt(string $module, string $key, array $replacements = []): string
    {
        return Coru\App::instance()->mt($module, $key, $replacements);
    }
}
$coru->modules->boot();