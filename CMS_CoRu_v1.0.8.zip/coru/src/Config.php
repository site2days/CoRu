<?php
declare(strict_types=1);

namespace Coru;

final class Config
{
    private array $data;

    public function __construct(private string $file)
    {
        $this->data = Yaml::load($file);
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $v = $this->data;
        foreach (explode('.', $key) as $k) {
            if (!is_array($v) || !array_key_exists($k, $v)) {
                return $default;
            }
            $v = $v[$k];
        }
        return $v;
    }

    public function set(string $key, mixed $value): void
    {
        $ref = &$this->data;
        foreach (explode('.', $key) as $k) {
            if (!isset($ref[$k]) || !is_array($ref[$k])) {
                $ref[$k] = [];
            }
            $ref = &$ref[$k];
        }
        $ref = $value;
    }

    public function all(): array
    {
        return $this->data;
    }

    public function save(): void
    {
        Yaml::save($this->file, $this->data);
    }
}