<?php
declare(strict_types=1);

namespace Coru;

final class Categories
{
    private array $items = [];
    private string $file;

    public function __construct(string $file = '')
    {
        $this->file = CORU_ROOT . '/adminpanel/data/categories.yaml';

        $data = Yaml::load($this->file);
        $items = is_array($data) ? ($data['categories'] ?? []) : [];

        if (is_array($items) && $items !== []) {
            // Оставляем только корректные записи категорий.
            $this->items = array_values(array_filter(
                $items,
                static fn($category): bool =>
                    is_array($category)
                    && isset($category['slug'], $category['title'])
                    && is_string($category['slug'])
                    && is_string($category['title'])
            ));
        }

        // Если файла нет или в нём нет категорий — создаём начальный список.
        if ($this->items === []) {
            $this->items = self::defaults();
            $this->save();
        }
    }

    public static function defaults(): array
    {
        $defaults = [
            'news'     => 'Новости',
            'articles' => 'Статьи',
            'blog'     => 'Блог',
            'gallery'  => 'Галерея',
            'goods'    => 'Товары',
            'services' => 'Услуги',
            'about'    => 'О нас',
            'contacts' => 'Контакты',
        ];

        $items = [];
        foreach ($defaults as $slug => $title) {
            $items[] = ['slug' => $slug, 'title' => $title];
        }

        return $items;
    }

    public function all(): array
    {
        return $this->items;
    }

    public function get(string $slug): ?array
    {
        foreach ($this->items as $category) {
            if ($category['slug'] === $slug) {
                return $category;
            }
        }

        return null;
    }

    public function add(string $title, string $slug = ''): bool
    {
        $title = trim($title);
        if ($title === '') {
            return false;
        }

        $slug = Pages::slugify($slug !== '' ? $slug : $title);

        if ($slug === '' || $this->get($slug) !== null) {
            return false;
        }

        $this->items[] = [
            'slug'  => $slug,
            'title' => $title,
        ];

        $this->save();
        return true;
    }

    public function rename(string $slug, string $title): void
    {
        $title = trim($title);

        foreach ($this->items as &$category) {
            if ($category['slug'] === $slug) {
                $category['title'] = $title;
                break;
            }
        }
        unset($category);

        $this->save();
    }

    public function remove(string $slug): void
    {
        $this->items = array_values(array_filter(
            $this->items,
            static fn(array $category): bool => $category['slug'] !== $slug
        ));

        $this->save();
    }

    public function save(): void
    {
        $dir = dirname($this->file);

        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new \RuntimeException('Не удалось создать каталог категорий: ' . $dir);
        }

        Yaml::save($this->file, ['categories' => $this->items]);
    }
}