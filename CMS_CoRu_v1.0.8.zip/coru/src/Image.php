<?php
declare(strict_types=1);

namespace Coru;

final class Image
{
    private const TYPES = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP];

    public static function isImage(string $file): bool
    {
        $info = @getimagesize($file);
        return $info !== false && in_array($info[2], self::TYPES, true);
    }

    /** cover-обрезка до точного размера $w×$h, результат — JPEG */
    public static function cropCover(string $src, string $dst, int $w, int $h, int $quality = 85): bool
    {
        $info = @getimagesize($src);
        if (!$info) {
            return false;
        }
        $im = match ($info[2]) {
            IMAGETYPE_JPEG => imagecreatefromjpeg($src),
            IMAGETYPE_PNG  => imagecreatefrompng($src),
            IMAGETYPE_GIF  => imagecreatefromgif($src),
            IMAGETYPE_WEBP => imagecreatefromwebp($src),
            default        => false,
        };
        if (!$im) {
            return false;
        }
        [$sw, $sh] = [$info[0], $info[1]];
        $scale = max($w / $sw, $h / $sh);
        $cw = (int)round($w / $scale);
        $ch = (int)round($h / $scale);
        $sx = (int)(($sw - $cw) / 2);
        $sy = (int)(($sh - $ch) / 2);

        $out = imagecreatetruecolor($w, $h);
        imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
        imagecopyresampled($out, $im, 0, 0, $sx, $sy, $w, $h, $cw, $ch);
        $ok = imagejpeg($out, $dst, $quality);
        imagedestroy($im);
        imagedestroy($out);
        return $ok;
    }

    public static function safeName(string $original): string
    {
        $ext  = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $base = Pages::slugify(pathinfo($original, PATHINFO_FILENAME));
        return $base . '-' . bin2hex(random_bytes(3)) . ($ext ? '.' . $ext : '');
    }
}