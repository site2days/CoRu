<?php
declare(strict_types=1);

namespace Coru;

final class Yaml
{
    /**
     * Регистрирует временный автозагрузчик для Symfony, 
     * так как библиотека лежит в \coru\symfony\yaml
     */
    private static function initSymfonyLoader(): void
    {
        // Проверяем, не зарегистрирован ли загрузчик ранее, чтобы избежать дублей
        if (!spl_autoload_functions() || !in_array([self::class, 'symfonyLoader'], spl_autoload_functions(), true)) {
            spl_autoload_register([self::class, 'symfonyLoader']);
        }
    }

    /**
     * Сам загрузчик, который преобразует \Symfony\... в путь \coru\symfony\...
     */
    private static function symfonyLoader(string $class): void
    {
        if (strpos($class, 'Symfony\\Component\\Yaml\\') === 0) {
            // Отрезаем пространство имен, оставляя только имя файла
            $relativePath = substr($class, strlen('Symfony\\Component\\Yaml\\'));
            // Заменяем обратные слеши на прямые для путей
            $filePath = CORU_ROOT . '/symfony/yaml/' . str_replace('\\', '/', $relativePath) . '.php';
            
            if (is_file($filePath)) {
                require $filePath;
            }
        }
    }

    public static function parse(string $text): array
    {
        // Сначала регистрируем наш костыль-загрузчик
        self::initSymfonyLoader();

        // Теперь class_exists сможет найти класс, так как загрузчик знает, где его искать
        if (class_exists(\Symfony\Component\Yaml\Yaml::class)) {
            $r = \Symfony\Component\Yaml\Yaml::parse($text);
            return is_array($r) ? $r : [];
        }
        return self::miniParse($text);
    }

    public static function dump(array $data): string
    {
        self::initSymfonyLoader();

        if (class_exists(\Symfony\Component\Yaml\Yaml::class)) {
            return \Symfony\Component\Yaml\Yaml::dump($data, 8, 2);
        }
        return self::miniDump($data);
    }

    public static function load(string $file): array
    {
        return is_file($file) ? self::parse((string)file_get_contents($file)) : [];
    }

    public static function save(string $file, array $data): void
    {
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        file_put_contents($file, self::dump($data), LOCK_EX);
    }

    /* ---------------- mini parser ---------------- */

    private static function miniParse(string $text): array
    {
        $lines = [];
        foreach (preg_split('/\r?\n/', $text) as $l) {
            if (trim($l) === '' || preg_match('/^\s*#/', $l)) {
                continue;
            }
            $lines[] = [strlen($l) - strlen(ltrim($l)), rtrim($l)];
        }
        $i = 0;
        return $lines ? self::block($lines, $i, $lines[0][0]) : [];
    }

    private static function block(array $lines, int &$i, int $indent): array
    {
        $out = [];
        $n   = count($lines);
        while ($i < $n) {
            [$ind, $raw] = $lines[$i];
            if ($ind < $indent) {
                break;
            }
            if ($ind > $indent) {
                $i++;
                continue;
            }
            $line = trim($raw);

            if ($line === '-' || str_starts_with($line, '- ')) {
                $val = trim(substr($line, 1));
                $i++;
                if ($val === '') {
                    $out[] = ($i < $n && $lines[$i][0] > $indent) ? self::block($lines, $i, $lines[$i][0]) : null;
                } elseif (preg_match('/^([\w.\-]+):\s*(.*)$/u', $val, $m)) {
                    $item = [$m[1] => self::scalar($m[2])];
                    if ($i < $n && $lines[$i][0] > $indent) {
                        $item += self::block($lines, $i, $lines[$i][0]);
                    }
                    $out[] = $item;
                } else {
                    $out[] = self::scalar($val);
                }
            } elseif (preg_match('/^("[^"]*"|\'[^\']*\'|[^:]+):\s*(.*)$/u', $line, $m)) {
                $key = trim($m[1], " \"'");
                $val = $m[2];
                $i++;
                if ($val === '') {
                    $out[$key] = ($i < $n && $lines[$i][0] > $indent) ? self::block($lines, $i, $lines[$i][0]) : [];
                } else {
                    $out[$key] = self::scalar($val);
                }
            } else {
                $i++;
            }
        }
        return $out;
    }

    private static function scalar(string $v): mixed
    {
        $v = trim($v);
        if ($v === '' || $v === '~' || $v === 'null') return null;
        if ($v === '[]' || $v === '{}') return [];
        if ($v === 'true')  return true;
        if ($v === 'false') return false;
        if ($v[0] === '"') {
            $d = json_decode($v, true);
            return is_string($d) ? $d : trim($v, '"');
        }
        if ($v[0] === "'") {
            return str_replace("''", "'", trim($v, "'"));
        }
        if ($v[0] === '[' && str_ends_with($v, ']')) {
            return array_map(fn($x) => self::scalar($x), array_filter(array_map('trim', explode(',', substr($v, 1, -1))), 'strlen'));
        }
        if (preg_match('/^-?\d+$/', $v))            return (int)$v;
        if (preg_match('/^-?\d+\.\d+$/', $v))       return (float)$v;
        return $v;
    }

    /* ---------------- mini dumper ---------------- */

    private static function miniDump(array $data, int $ind = 0): string
    {
        $pad    = str_repeat(' ', $ind);
        $out    = '';
        $isList = array_is_list($data);
        foreach ($data as $k => $v) {
            if ($isList) {
                if (is_array($v)) {
                    if ($v === []) { $out .= "{$pad}- []\n"; continue; }
                    $inner = explode("\n", rtrim(self::miniDump($v, $ind + 2), "\n"));
                    $out  .= $pad . '- ' . ltrim(array_shift($inner)) . "\n";
                    foreach ($inner as $l) { $out .= $l . "\n"; }
                } else {
                    $out .= "{$pad}- " . self::scalarDump($v) . "\n";
                }
            } else {
                if (is_array($v)) {
                    $out .= $v === [] ? "{$pad}{$k}: []\n" : "{$pad}{$k}:\n" . self::miniDump($v, $ind + 2);
                } else {
                    $out .= "{$pad}{$k}: " . self::scalarDump($v) . "\n";
                }
            }
        }
        return $out;
    }

    private static function scalarDump(mixed $v): string
    {
        if ($v === null)  return 'null';
        if (is_bool($v))  return $v ? 'true' : 'false';
        if (is_int($v) || is_float($v)) return (string)$v;
        $s = (string)$v;
        $plain = preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _.\-\/]*$/u', $s)
            && !is_numeric($s)
            && !in_array(strtolower($s), ['true', 'false', 'null', 'yes', 'no', '~'], true);
        return $plain ? $s : (string)json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}