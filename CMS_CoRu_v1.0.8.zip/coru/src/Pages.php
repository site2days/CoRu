<?php
declare(strict_types=1);

namespace Coru;

final class Pages
{
    private const TRANSLIT = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y',
        'к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f',
        'х'=>'h','ц'=>'c','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
    ];

    public function __construct(private string $dir)
    {
        foreach (['', '/picture', '/media'] as $d) {
            if (!is_dir($dir . $d)) {
                mkdir($dir . $d, 0775, true);
            }
        }
    }

    public static function slugify(string $s): string
    {
        $s = strtr(mb_strtolower(trim($s)), self::TRANSLIT);
        $s = trim((string)preg_replace('/[^a-z0-9]+/', '-', $s), '-');
        return $s !== '' ? $s : 'page-' . time();
    }

    public static function validSlug(string $slug): bool
    {
        return (bool)preg_match('/^[a-z0-9][a-z0-9\-]{0,120}$/', $slug);
    }

    public function file(string $slug): string
    {
        return $this->dir . '/' . $slug . '.html';
    }

    public function exists(string $slug): bool
    {
        return self::validSlug($slug) && is_file($this->file($slug));
    }

    public function get(string $slug): ?array
    {
        if (!$this->exists($slug)) {
            return null;
        }
        return $this->parse($slug, (string)file_get_contents($this->file($slug)));
    }

    private function parse(string $slug, string $raw): array
    {
        $meta = [];
        $content = $raw;
        if (preg_match('/\A---\R(.*?)\R---\R?(.*)\z/su', $raw, $m)) {
            $meta    = Yaml::parse($m[1]);
            $content = $m[2];
        }
        return [
            'slug'        => $slug,
            'title'       => (string)($meta['title'] ?? $slug),
            'category'    => (string)($meta['category'] ?? ''),
            'keywords'    => (string)($meta['keywords'] ?? ''),
            'description' => (string)($meta['description'] ?? ''),
            'image'       => (string)($meta['image'] ?? ''),
            'date'        => (string)($meta['date'] ?? date('Y-m-d', filemtime($this->file($slug)) ?: time())),
            'author'      => (string)($meta['author'] ?? ''),
            'published'   => (bool)($meta['published'] ?? true),
            'content'     => $content,
        ];
    }

    /** @return array[] */
    public function all(bool $onlyPublished = false): array
    {
        $list = [];
        foreach (glob($this->dir . '/*.html') ?: [] as $f) {
            $slug = basename($f, '.html');
            if (!self::validSlug($slug)) {
                continue;
            }
            $p = $this->parse($slug, (string)file_get_contents($f));
            if ($onlyPublished && !$p['published']) {
                continue;
            }
            $list[] = $p;
        }
        usort($list, fn($a, $b) => strcmp($b['date'], $a['date']));
        return $list;
    }

    public function search(string $q): array
    {
        $q = mb_strtolower(trim($q));
        return array_values(array_filter($this->all(), fn($p) => $q === '' || mb_stripos($p['title'], $q) !== false));
    }

    public function byCategory(string $cat, bool $onlyPublished = true): array
    {
        return array_values(array_filter($this->all($onlyPublished), fn($p) => $p['category'] === $cat));
    }

    public function save(string $slug, array $meta, string $html): void
    {
        if (!self::validSlug($slug)) {
            throw new \InvalidArgumentException('Bad slug');
        }
        unset($meta['content'], $meta['slug']);
        file_put_contents($this->file($slug), "---\n" . Yaml::dump($meta) . "---\n" . $html, LOCK_EX);
    }

    public function delete(string $slug): void
    {
        if ($this->exists($slug)) {
            unlink($this->file($slug));
            $img = $this->dir . '/picture/' . $slug . '-main.jpg';
            if (is_file($img)) {
                unlink($img);
            }
        }
    }
}