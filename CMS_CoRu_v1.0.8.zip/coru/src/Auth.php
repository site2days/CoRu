<?php
declare(strict_types=1);

namespace Coru;

final class Auth
{
    public const ROLES = [
        'admin'       => 4,
        'editor'      => 3,
        'commentator' => 2,
        'user'        => 1,
    ];

    private string $admFile;
    private string $usersDir;

    public function __construct(private App $app)
    {
        $this->admFile = CORU_ROOT . '/adminpanel/adm.yaml';
        $this->usersDir = CORU_ROOT . '/users';

        if (!is_dir($this->usersDir)) {
            mkdir($this->usersDir, 0775, true);
        }
    }

    public static function cleanLogin(string $login): string
    {
        return strtolower((string)preg_replace('/[^a-z0-9_-]/i', '', $login));
    }

    public function userFile(string $login): string
    {
        return $this->usersDir . '/' . self::cleanLogin($login) . '.yaml';
    }

    public function hasAdmin(): bool
    {
        return !empty(Yaml::load($this->admFile)['users']);
    }

    public function createAdmin(string $login, string $password, string $email = ''): void
    {
        $adm = Yaml::load($this->admFile);
        $adm['roles'] = array_keys(self::ROLES);
        $adm['users'] ??= [];
        $adm['users'][] = [
            'login'       => self::cleanLogin($login),
            'password'    => password_hash($password, PASSWORD_DEFAULT),
            'role'        => 'admin',
            'permissions' => ['*'],
            'email'       => $email,
            'created'     => date('c'),
        ];

        Yaml::save($this->admFile, $adm);
    }

    public function findUser(string $login): ?array
    {
        $login = self::cleanLogin($login);

        foreach (Yaml::load($this->admFile)['users'] ?? [] as $user) {
            if (($user['login'] ?? '') === $login) {
                return $user + [
                    'status' => 'active',
                    'source' => 'adm',
                ];
            }
        }

        $file = $this->userFile($login);

        return is_file($file)
            ? Yaml::load($file) + ['source' => 'users']
            : null;
    }

public function attempt(string $login, string $password): bool
{
    $user = $this->findUser($login);

    if (
        !$user
        || !password_verify($password, (string)($user['password'] ?? ''))
        || ($user['status'] ?? 'active') !== 'active'
    ) {
        return false;
    }

    $role = (string)($user['role'] ?? '');

    if (!isset(self::ROLES[$role])) {
        return false;
    }

    session_regenerate_id(true);

    $_SESSION['coru_user'] = [
        'login'       => (string)$user['login'],
        'role'        => $role,
        'email'       => (string)($user['email'] ?? ''),
        'avatar'      => (string)($user['avatar'] ?? ''),
        'permissions' => $this->cleanPermissions($user['permissions'] ?? []),
    ];

    return true;
}

    public function logout(): void
    {
        unset($_SESSION['coru_user']);
        session_regenerate_id(true);
    }

    public function user(): ?array
    {
        return $_SESSION['coru_user'] ?? null;
    }

    public function check(): bool
    {
        return $this->user() !== null;
    }

    /**
     * Проверяет роль по существующей иерархии.
     * Пример: can('editor') разрешает editor и admin.
     */
    public function can(string $role): bool
    {
        $user = $this->user();

        if (!$user) {
            return false;
        }

        $userLevel = self::ROLES[$user['role'] ?? ''] ?? 0;
        $requiredLevel = self::ROLES[$role] ?? PHP_INT_MAX;

        return $userLevel >= $requiredLevel;
    }

    /**
     * Проверяет отдельное разрешение для пункта меню или функции.
     * Admin имеет все права. Остальные — только выданные им permissions.
     */
    public function hasPermission(string $permission): bool
    {
        $user = $this->user();

        if (!$user) {
            return false;
        }

        if (($user['role'] ?? '') === 'admin') {
            return true;
        }

        $permissions = $this->cleanPermissions($user['permissions'] ?? []);

        return in_array('*', $permissions, true)
            || in_array($permission, $permissions, true);
    }

    /**
     * Используйте в защищённых страницах для проверки роли.
     */
    public function requireRole(string $role): void
    {
        if (!$this->can($role)) {
            App::flash($this->app->t('admin.access_denied'), 'err');
            App::redirect($this->app->url('/adminpanel/login.php'));
        }
    }

    /**
     * Используйте в защищённых страницах для проверки разрешения.
     */
    public function requirePermission(string $permission): void
    {
        if (!$this->hasPermission($permission)) {
            http_response_code(403);
            exit($this->app->t('admin.access_denied'));
        }
    }

    /** @return true|string */
    public function register(
        string $login,
        string $password,
        string $email,
        string $role
    ): true|string {
        $login = self::cleanLogin($login);

        if (strlen($login) < 3) {
            return 'reg_bad_login';
        }

        if (strlen($password) < 8) {
            return 'reg_bad_pass';
        }

        if (!in_array($role, ['editor', 'commentator', 'user'], true)) {
            return 'reg_bad_role';
        }

        if ($this->findUser($login)) {
            return 'reg_exists';
        }
	Yaml::save($this->userFile($login), [
    	'login'       => $login,
    	'password'    => password_hash($password, PASSWORD_DEFAULT),
    	'email'       => $email,
   	'role'        => $role,
	'permissions' => match ($role) {
	'editor' => [
        'admin.profile',
        'admin.pages',
        'admin.media',
        'admin.translate',
        'admin.lang',
   	 ],
    	'commentator' => [
        'admin.profile',
        'admin.pages',
        'admin.lang',
    	],
    	default => [],
	},
   	'status'      => 'pending',
    	'created'     => date('c'),
]);

        return true;
    }

    /** @return array[] */
    public function users(?string $status = null): array
    {
        $out = [];

        foreach (glob($this->usersDir . '/*.yaml') ?: [] as $file) {
            $user = Yaml::load($file);

            if ($status === null || ($user['status'] ?? '') === $status) {
                $out[] = $user;
            }
        }

        return $out;
    }

    public function admins(): array
    {
        return Yaml::load($this->admFile)['users'] ?? [];
    }

    public function updateUser(string $login, array $patch): void
    {
        $login = self::cleanLogin($login);
        $adm = Yaml::load($this->admFile);

        foreach ($adm['users'] ?? [] as $index => $user) {
            if (($user['login'] ?? '') === $login) {
                $adm['users'][$index] = array_merge($user, $patch);
                Yaml::save($this->admFile, $adm);
                $this->refreshSession($login, $patch);
                return;
            }
        }

        $file = $this->userFile($login);

        if (is_file($file)) {
            $user = Yaml::load($file);
            Yaml::save($file, array_merge($user, $patch));
            $this->refreshSession($login, $patch);
        }
    }

public function renameAdminLogin(string $oldLogin, string $newLogin): true|string
{
    // Менять логин может только пользователь с ролью admin.
    if (($this->user()['role'] ?? '') !== 'admin') {
        return 'access_denied';
    }

    $oldLogin = self::cleanLogin($oldLogin);
    $newLogin = self::cleanLogin($newLogin);

    if (strlen($newLogin) < 3) {
        return 'reg_bad_login';
    }

    if ($oldLogin === $newLogin) {
        return true;
    }

    // Не разрешаем занять логин другого администратора или пользователя.
    if ($this->findUser($newLogin) !== null) {
        return 'reg_exists';
    }

    $adm = Yaml::load($this->admFile);
    $found = false;

    foreach ($adm['users'] ?? [] as $index => $user) {
        if (($user['login'] ?? '') === $oldLogin) {
            $adm['users'][$index]['login'] = $newLogin;
            $found = true;
            break;
        }
    }

    if (!$found) {
        return 'user_not_found';
    }

    Yaml::save($this->admFile, $adm);

    // Обновляем логин текущей сессии, чтобы администратор не вышел из аккаунта.
    if (($this->user()['login'] ?? null) === $oldLogin) {
        $_SESSION['coru_user']['login'] = $newLogin;
    }

    return true;
}

    public function deleteUser(string $login): void
    {
        $file = $this->userFile($login);

        if (is_file($file)) {
            unlink($file);
        }
    }

    private function refreshSession(string $login, array $patch): void
    {
        if (($this->user()['login'] ?? null) !== $login) {
            return;
        }

        $allowed = ['email', 'avatar', 'role', 'permissions'];
        $sessionPatch = array_intersect_key($patch, array_flip($allowed));

        if (isset($sessionPatch['permissions'])) {
            $sessionPatch['permissions'] = $this->cleanPermissions(
                $sessionPatch['permissions']
            );
        }

        $_SESSION['coru_user'] = array_merge(
            $_SESSION['coru_user'],
            $sessionPatch
        );
    }

    private function cleanPermissions(mixed $permissions): array
    {
        if (!is_array($permissions)) {
            return [];
        }

        $clean = [];

        foreach ($permissions as $permission) {
            if (!is_string($permission)) {
                continue;
            }

            $permission = trim($permission);

            if ($permission !== '' && preg_match('/^[a-z0-9_.*-]+$/i', $permission)) {
                $clean[] = $permission;
            }
        }

        return array_values(array_unique($clean));
    }

    public static function csrf(): string
    {
        return $_SESSION['coru_csrf'] ??= bin2hex(random_bytes(32));
    }

    public static function checkCsrf(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            return;
        }

        $submitted = (string)($_POST['_csrf'] ?? '');

        if (!hash_equals(self::csrf(), $submitted)) {
            http_response_code(419);
            exit('CSRF token mismatch');
        }
    }

    public static function csrfField(): string
    {
        return '<input type="hidden" name="_csrf" value="'
            . htmlspecialchars(self::csrf(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            . '">';
    }
}