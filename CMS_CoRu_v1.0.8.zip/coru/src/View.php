<?php
declare(strict_types=1);

namespace Coru;

use Twig\Environment;
use Twig\Loader\FilesystemLoader;
use Twig\TwigFunction;

final class View
{
    private Environment $twig;

    public function __construct(private App $app)
    {
        $theme = (string)$app->config->get('site.theme', 'coru-default');
        $dir   = CORU_ROOT . '/themes/' . basename($theme);
        $cache = CORU_ROOT . '/coru/cache/twig';
        if (!is_dir($cache)) {
            mkdir($cache, 0775, true);
        }

        $this->twig = new Environment(new FilesystemLoader([$dir]), [
            'cache'       => $cache,
            'auto_reload' => true,
            'autoescape'  => 'html',
        ]);

        $this->twig->addGlobal('site', $app->config->get('site', []));
        $this->twig->addGlobal('categories', $app->categories->all());
        $this->twig->addGlobal('user', $app->auth->user());
        $this->twig->addGlobal('lang', $app->lang->code);
        $this->twig->addGlobal('theme_url', $app->url('/themes/' . basename($theme)));
// перевод для модулей
	$this->twig->addFunction(new TwigFunction('mt', fn(string $module, string $key, array $r = []) => $app->mt($module, $key, $r)));

        $this->twig->addFunction(new TwigFunction('t', fn(string $k, array $r = []) => $app->t($k, $r)));
        $this->twig->addFunction(new TwigFunction('url', fn(string $p = '') => $app->url($p)));
        $this->twig->addFunction(new TwigFunction('page_url', fn(string $slug) => $app->pageUrl($slug)));
//        $this->twig->addFunction(new TwigFunction('cat_url', fn(string $slug) => $app->url('?cat=' . rawurlencode($slug))));
$this->twig->addFunction(new TwigFunction(
    'cat_url',
    fn(string $slug) => $app->config->get('site.pretty_urls')
        ? $app->url('category/' . rawurlencode($slug))
        : $app->url('?cat=' . rawurlencode($slug))
));
    }

    public function twig(): Environment
    {
        return $this->twig;
    }

    public function render(string $template, array $vars = []): string
    {
        return $this->twig->render($template, $vars);
    }
}