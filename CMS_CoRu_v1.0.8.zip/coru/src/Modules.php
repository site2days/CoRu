<?php
declare(strict_types=1);

namespace Coru;

final class Modules
{
    private array $state;
    private string $stateFile;

    public function __construct(private App $app, private string $dir)
    {
        $this->stateFile = CORU_ROOT . '/adminpanel/data/modules.yaml';
        $this->state     = Yaml::load($this->stateFile)['enabled'] ?? [];
    }

    /** slug => manifest */
    public function all(): array
    {
        $out = [];
        foreach (glob($this->dir . '/*/manifest.yaml') ?: [] as $f) {
            $slug = basename(dirname($f));
            $m = Yaml::load($f);
            $m['slug']    = $slug;
            $m['path']    = dirname($f);
            $m['enabled'] = array_key_exists($slug, $this->state) ? (bool)$this->state[$slug] : (bool)($m['enabled'] ?? true);
            $out[$slug]   = $m;
        }
        return $out;
    }

    public function isEnabled(string $slug): bool
    {
        return $this->all()[$slug]['enabled'] ?? false;
    }

    public function setEnabled(string $slug, bool $on): void
    {
        $this->state[$slug] = $on;
        Yaml::save($this->stateFile, ['enabled' => $this->state]);
    }

    /** подключает включённые модули с autoload: true (они получают $coru) */
    public function boot(): void
    {
        $coru = $this->app;
        foreach ($this->all() as $m) {
            if (!$m['enabled'] || empty($m['autoload']) || empty($m['entry'])) {
                continue;
            }
            $file = $m['path'] . '/' . basename((string)$m['entry']);
            if (is_file($file)) {
                require_once $file;
            }
        }
    }
}