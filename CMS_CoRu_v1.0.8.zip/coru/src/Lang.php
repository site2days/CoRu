<?php
declare(strict_types=1);

namespace Coru;

final class Lang
{
    private array $strings;
    private array $fallback;
    public readonly string $code;

    public function __construct(private string $dir, string $code)
    {
        $code = preg_replace('/[^a-z]/', '', strtolower($code)) ?: 'en';
        $this->code     = is_file("$dir/$code.yaml") ? $code : 'en';
        $this->fallback = Yaml::load("$dir/en.yaml");
        $this->strings  = Yaml::load("$dir/{$this->code}.yaml") ?: $this->fallback;
    }

    public function t(string $key, array $repl = []): string
    {
        $v = $this->find($this->strings, $key) ?? $this->find($this->fallback, $key) ?? $key;
        foreach ($repl as $k => $r) {
            $v = str_replace('{' . $k . '}', (string)$r, $v);
        }
        return $v;
    }
// перевод модулей какждый со своей функцией перевода
public function moduleT(string $module, string $key, array $repl = []): string
{
    // Имя модуля и ключи принимают только безопасные символы.
    if (!preg_match('/^[a-z0-9_-]+$/i', $module)) {
        return $key;
    }

    $moduleDir = CORU_ROOT . '/modules/' . $module . '/lang';
    $currentCode = $this->code;
    $fallbackCode = 'en';

    $current = Yaml::load($moduleDir . '/' . $currentCode . '.yaml');
    $fallback = $currentCode === $fallbackCode
        ? $current
        : Yaml::load($moduleDir . '/' . $fallbackCode . '.yaml');

    $value = $this->find($current, $key)
        ?? $this->find($fallback, $key)
        ?? $key;

    foreach ($repl as $name => $replacement) {
        $value = str_replace('{' . $name . '}', (string)$replacement, $value);
    }

    return $value;
}

    private function find(array $a, string $key): ?string
    {
        foreach (explode('.', $key) as $k) {
            if (!is_array($a) || !array_key_exists($k, $a)) {
                return null;
            }
            $a = $a[$k];
        }
        return is_scalar($a) ? (string)$a : null;
    }

    /** @return string[] codes */
    public function available(): array
    {
        return array_map(fn($f) => basename($f, '.yaml'), glob($this->dir . '/*.yaml') ?: []);
    }

    public function file(string $code): string
    {
        return $this->dir . '/' . preg_replace('/[^a-z]/', '', strtolower($code)) . '.yaml';
    }
}