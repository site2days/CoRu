<?php
declare(strict_types=1);

namespace Coru;

final class App
{
    private static ?App $inst = null;

    public Config $config;
    public Lang $lang;
    public Auth $auth;
    public Pages $pages;
    public Categories $categories;
    public Modules $modules;

    private ?View $view = null;
    private array $routes = [];
    private array $hooks = [];

    public static function instance(): App
    {
        return self::$inst ??= new App();
    }

    private function __construct()
    {
        $this->config     = new Config(CORU_ROOT . '/coru/config.yaml');
        $this->auth       = new Auth($this);
        $this->lang       = new Lang(CORU_ROOT . '/coru/languages', $_SESSION['coru_lang'] ?? (string)$this->config->get('site.lang', 'ru'));
        $this->pages      = new Pages(CORU_ROOT . '/site');
        $this->categories = new Categories(CORU_ROOT . '/adminpanel/data/categories.yaml');
// отладка чтения categories.yaml
// var_dump($categories); // или var_dump($coru->categories);
// die;
// отладка 

        $this->modules    = new Modules($this, CORU_ROOT . '/modules');
    }

    public function view(): View
    {
        return $this->view ??= new View($this);
    }
// перевод
    public function t(string $key, array $repl = []): string
    {
        return $this->lang->t($key, $repl);
    }
// для модулей
public function mt(string $module, string $key, array $repl = []): string
{
    return $this->lang->moduleT($module, $key, $repl);
}

    /* ---- routes for modules (goods, chat, ...) ---- */
    public function route(string $path, callable $handler): void
    {
        $this->routes[trim($path, '/')] = $handler;
    }

    public function matchRoute(string $path): ?callable
    {
        foreach ($this->routes as $p => $h) {
            if ($path === $p || str_starts_with($path, $p . '/')) {
                return $h;
            }
        }
        return null;
    }

    /* ---- hooks ---- */
    public function on(string $event, callable $handler): void
    {
        $this->hooks[$event][] = $handler;
    }

    public function fire(string $event, array $args = []): void
    {
        foreach ($this->hooks[$event] ?? [] as $h) {
            $h(...$args);
        }
    }

    /* ---- urls ---- */
    public function baseUrl(): string
    {
        $cfg = (string)$this->config->get('site.base_url', '');
        if ($cfg !== '') {
            return rtrim($cfg, '/');
        }
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        return $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }

/* SLUG */
    public function url(string $path = ''): string
    {
        return $this->baseUrl() . '/' . ltrim($path, '/');
    }

/**  было  public function pageUrl(string $slug): string
 *    {
 *        return $this->config->get('site.pretty_urls') ? $this->url($slug) : $this->url('?p=' . rawurlencode($slug));
 *    }
 */
	public function pageUrl(string $slug): string
	{
    	return $this->config->get('site.pretty_urls')
        ? $this->url(rawurlencode($slug))
        : $this->url('?p=' . rawurlencode($slug));
	}

    public function requestPath(): string
    {
        if (isset($_GET['p'])) {
            return trim((string)$_GET['p'], '/');
        }
        $uri  = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        }
        return trim(rawurldecode($uri), '/');
    }

    /* ---- helpers ---- */
    public static function redirect(string $url): never
    {
        header('Location: ' . $url);
        exit;
    }

    public static function e(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function flash(?string $msg = null, string $type = 'ok'): ?array
    {
        if ($msg !== null) {
            $_SESSION['coru_flash'] = [$msg, $type];
            return null;
        }
        $f = $_SESSION['coru_flash'] ?? null;
        unset($_SESSION['coru_flash']);
        return $f;
    }
}