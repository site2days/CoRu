    /** Модуль выключен в /adminpanel/data/modules.yaml */
    public static function disabled(string $name): bool
    {
        $data  = Yaml::parseFile(CORU_USERS . '/modules.yaml');
        $state = is_array($data['modules'] ?? null) ? $data['modules'] : [];
        return isset($state[$name]) && !((bool) ($state[$name]['enabled'] ?? true));
    }

    public static function all(bool $onlyEnabled = false): array
    {
        $out = [];
        foreach (glob(CORU_MODULES . '/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $name = basename($dir);
            if (!is_file($dir . '/manifest.yaml')) {
                continue;
            }
            try {
                $manifest = self::manifest($name);
            } catch (\Throwable) {
                continue;
            }
            if ($onlyEnabled && self::disabled($name)) {
                continue;
            }
            $out[$name] = $manifest;
        }
        return $out;
    }

    /** Запускает модуль и возвращает его HTML-фрагмент (или null для JSON-ответов). */
    public static function run(string $name): mixed
    {
        $manifest = self::manifest($name);

        if (self::disabled($name)) {
            coru_json(['ok' => false, 'error' => "Модуль {$name} отключён администратором."], 403);
        }

        // Права из modules.yaml перекрывают manifest.yaml
        $data  = Yaml::parseFile(CORU_USERS . '/modules.yaml');
        $state = is_array($data['modules'] ?? null) ? $data['modules'] : [];
        $roles = (array) ($state[$name]['roles'] ?? []);
        if ($roles === []) {
            $roles = (array) ($manifest['roles'] ?? ['admin']);
        }
        if (!in_array('admin', $roles, true)) {
            $roles[] = 'admin';
        }

        Auth::requireRole(...$roles);

        $entry = self::dir($name) . '/' . (string) ($manifest['entry'] ?? $name . '.php');
        if (!is_file($entry)) {
            throw new \RuntimeException("Точка входа модуля не найдена: {$entry}");
        }
        require_once $entry;

        $class = (string) ($manifest['class'] ?? '');
        if ($class !== '' && class_exists($class) && method_exists($class, 'handle')) {
            return $class::handle();
        }
        return null;
    }