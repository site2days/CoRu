<?php
declare(strict_types=1);

namespace Coru;

final class Autoload
{
    /** namespace prefix => directory (PSR-4) */
    private static array $map = [
        'Coru\\'                    => CORU_ROOT . '/coru/src/',
        'Twig\\'                    => CORU_ROOT . '/coru/twig/src/',
        'Symfony\\Component\\Yaml\\' => CORU_ROOT . '/coru/symfony/yaml/',
    ];

    public static function register(): void
    {
        spl_autoload_register([self::class, 'load']);
    }

    public static function add(string $prefix, string $dir): void
    {
        self::$map[$prefix] = rtrim($dir, '/') . '/';
    }

    public static function load(string $class): void
    {
        foreach (self::$map as $prefix => $dir) {
            if (str_starts_with($class, $prefix)) {
                $file = $dir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
                if (is_file($file)) {
                    require $file;
                }
                return;
            }
        }
    }
}