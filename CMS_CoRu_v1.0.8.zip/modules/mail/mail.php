<?php
/**
 * Coru module: mail — SMTP-клиент без зависимостей.
 * Подключается ядром при загрузке (autoload: true) → доступны coru_mail() и маршрут "contact".
 * Открыт напрямую → страница теста в админке (роль admin).
 */
declare(strict_types=1);

final class CoruMailer
{
    private string $log;

    public function __construct(private array $cfg)
    {
        $this->log = __DIR__ . '/mail.log';
    }

    public static function fromYaml(): self
    {
        return new self(Coru\Yaml::load(__DIR__ . '/mail.yaml'));
    }

    /** @return true|string  true или текст ошибки */
    public function send(string $to, string $subject, string $body, bool $html = false, string $replyTo = ''): true|string
    {
        $c    = $this->cfg;
        $host = (string)($c['host'] ?? '');
        $port = (int)($c['port'] ?? 587);
        $enc  = strtolower((string)($c['encryption'] ?? 'tls'));
        $tout = (int)($c['timeout'] ?? 15);
        if ($host === '' || empty($c['from_email'])) {
            return $this->fail('mail.yaml: host/from_email not set');
        }

        $fp = @stream_socket_client(($enc === 'ssl' ? 'ssl://' : 'tcp://') . "$host:$port", $errno, $errstr, $tout);
        if (!$fp) {
            return $this->fail("connect: $errstr ($errno)");
        }
        stream_set_timeout($fp, $tout);

        $read = function () use ($fp): string {
            $data = '';
            while (($line = fgets($fp, 515)) !== false) {
                $data .= $line;
                if (isset($line[3]) && $line[3] === ' ') break;
            }
            return $data;
        };
        $cmd = function (string $cmd, array $ok) use ($fp, $read): void {
            fwrite($fp, $cmd . "\r\n");
            $r = $read();
            if (!in_array((int)substr($r, 0, 3), $ok, true)) {
                throw new RuntimeException(trim(preg_replace('/^AUTH .*|^[A-Za-z0-9+\/=]{20,}$/', '***', $cmd) ?? $cmd) . ' -> ' . trim($r));
            }
        };

        try {
            if ((int)substr($read(), 0, 3) !== 220) throw new RuntimeException('no 220 greeting');
            $ehlo = 'EHLO ' . ((string)($c['hostname'] ?? '') ?: (gethostname() ?: 'localhost'));
            $cmd($ehlo, [250]);
            if ($enc === 'tls') {
                $cmd('STARTTLS', [220]);
                if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('STARTTLS failed');
                $cmd($ehlo, [250]);
            }
            if (!empty($c['username'])) {
                $cmd('AUTH LOGIN', [334]);
                $cmd(base64_encode((string)$c['username']), [334]);
                $cmd(base64_encode((string)($c['password'] ?? '')), [235]);
            }
            $cmd('MAIL FROM:<' . $c['from_email'] . '>', [250]);
            $rcpts = array_filter(array_map('trim', explode(',', $to)));
            foreach ($rcpts as $r) {
                if (!filter_var($r, FILTER_VALIDATE_EMAIL)) throw new RuntimeException("bad recipient: $r");
                $cmd("RCPT TO:<$r>", [250, 251]);
            }
            $cmd('DATA', [354]);

            $enc64 = fn(string $s) => '=?UTF-8?B?' . base64_encode($s) . '?=';
            $headers = [
                'Date: ' . date('r'),
                'From: ' . $enc64((string)($c['from_name'] ?? 'Coru')) . ' <' . $c['from_email'] . '>',
                'To: ' . implode(', ', $rcpts),
                'Subject: ' . $enc64($subject),
                'Message-ID: <' . bin2hex(random_bytes(8)) . '@' . $host . '>',
                'MIME-Version: 1.0',
                'Content-Type: ' . ($html ? 'text/html' : 'text/plain') . '; charset=UTF-8',
                'Content-Transfer-Encoding: base64',
                'X-Mailer: Coru CMS',
            ];
            if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
                $headers[] = "Reply-To: <$replyTo>";
            }
            $data = implode("\r\n", $headers) . "\r\n\r\n" . chunk_split(base64_encode($body), 76, "\r\n");
            $cmd($data . '.', [250]);
            $cmd('QUIT', [221]);
        } catch (Throwable $e) {
            fclose($fp);
            return $this->fail($e->getMessage());
        }
        fclose($fp);
        $this->write("OK to=$to subject=$subject");
        return true;
    }

    private function fail(string $msg): string
    {
        $this->write('ERR ' . $msg);
        return $msg;
    }

    private function write(string $line): void
    {
        @file_put_contents($this->log, date('c') . ' ' . $line . "\n", FILE_APPEND | LOCK_EX);
    }
}

if (!function_exists('coru_mail')) {
    /** @return true|string */
    function coru_mail(string $to, string $subject, string $body, bool $html = false, string $replyTo = ''): true|string
    {
        return CoruMailer::fromYaml()->send($to, $subject, $body, $html, $replyTo);
    }
}

/* ---------- режим подключения ядром: маршрут /?p=contact ---------- */
if (isset($coru) && $coru instanceof Coru\App && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== __FILE__) {
    $coru->route('contact', function (Coru\App $coru, string $path): string {
        $twig = $coru->view()->twig();
        $loader = $twig->getLoader();
        if ($loader instanceof Twig\Loader\FilesystemLoader) {
            $loader->addPath(__DIR__ . '/templates', 'mail');
        }
        $sent = false; $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Coru\Auth::checkCsrf();
            $name  = trim(strip_tags((string)($_POST['name'] ?? '')));
            $email = filter_var((string)($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL) ?: '';
            $msg   = trim((string)($_POST['message'] ?? ''));
            if ($name === '' || $email === '' || $msg === '') {
                $error = 'empty fields';
            } else {
                $cfg = Coru\Yaml::load(__DIR__ . '/mail.yaml');
                $r = coru_mail((string)($cfg['to'] ?? $cfg['from_email'] ?? ''), "[{$coru->config->get('site.title')}] $name",
                    "Name: $name\nE-mail: $email\nIP: {$_SERVER['REMOTE_ADDR']}\n\n$msg", false, $email);
                $sent  = $r === true;
                $error = $sent ? '' : (string)$r;
            }
        }
        return $twig->render('@mail/contact.html.twig', ['sent' => $sent, 'error' => $error, 'csrf' => Coru\Auth::csrf()]);
    });
    return;
}

/* SET & test in admin  */
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $coruMinRole = 'admin';

    require dirname(__DIR__, 2) . '/adminpanel/inc/boot.php';
    require CORU_ROOT . '/adminpanel/inc/layout.php';

    $cfg = Coru\Yaml::load(__DIR__ . '/mail.yaml');
    $result = null;
    $saveError = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = (string)($_POST['do'] ?? '');

        if ($action === 'save_settings') {
            $host = trim((string)($_POST['host'] ?? ''));
            $port = filter_var(
                $_POST['port'] ?? null,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1, 'max_range' => 65535]]
            );
            $encryption = (string)($_POST['encryption'] ?? '');
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $fromEmail = filter_var(
                trim((string)($_POST['from_email'] ?? '')),
                FILTER_VALIDATE_EMAIL
            );
            $fromName = trim((string)($_POST['from_name'] ?? ''));
            $to = trim((string)($_POST['to'] ?? ''));
            $timeout = filter_var(
                $_POST['timeout'] ?? 15,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1, 'max_range' => 120]]
            );

            $validEncryption = in_array($encryption, ['tls', 'ssl', 'none'], true);
            $validRecipients = $to !== '';

            foreach (array_filter(array_map('trim', explode(',', $to))) as $recipient) {
                if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
                    $validRecipients = false;
                    break;
                }
            }

            if ($host === '' || !preg_match('/^[a-zA-Z0-9.-]+$/', $host)) {
                $saveError = 'Укажите корректный SMTP host.';
            } elseif ($port === false) {
                $saveError = 'Порт должен быть числом от 1 до 65535.';
            } elseif (!$validEncryption) {
                $saveError = 'Выберите tls, ssl или none.';
            } elseif ($fromEmail === false) {
                $saveError = 'Укажите корректный адрес отправителя.';
            } elseif (!$validRecipients) {
                $saveError = 'Укажите корректный адрес получателя; несколько адресов разделяйте запятыми.';
            } elseif ($timeout === false) {
                $saveError = 'Timeout должен быть от 1 до 120 секунд.';
            } else {
                $cfg['host'] = $host;
                $cfg['port'] = $port;
                $cfg['encryption'] = $encryption;
                $cfg['username'] = $username;
                $cfg['from_email'] = $fromEmail;
                $cfg['from_name'] = $fromName;
                $cfg['to'] = $to;
                $cfg['timeout'] = $timeout;

                // Пустое поле пароля означает «оставить прежний пароль».
                if ($password !== '') {
                    $cfg['password'] = $password;
                }

                try {
                    Coru\Yaml::save(__DIR__ . '/mail.yaml', $cfg);
                    Coru\App::flash('Настройки SMTP сохранены.');
                    Coru\App::redirect('mail.php');
                } catch (Throwable $e) {
                    $saveError = 'Не удалось сохранить mail.yaml. Проверьте права записи.';
                }
            }
        } elseif ($action === 'send_test') {
            $result = coru_mail(
                (string)($_POST['test_to'] ?? ''),
                (string)($_POST['subject'] ?? ''),
                (string)($_POST['body'] ?? '')
            );

            // Обновляем отображаемую конфигурацию после отправки.
            $cfg = Coru\Yaml::load(__DIR__ . '/mail.yaml');
        }
    }

    coru_admin_header('Mail (SMTP)');
    ?>

    <div class="coru-card">
      <h3>Настройки SMTP</h3>

      <?php if ($saveError !== ''): ?>
        <div class="coru-flash err"><?= e($saveError) ?></div>
      <?php endif; ?>

      <form method="post" class="coru-form" style="max-width:700px">
        <?= coru_csrf() ?>
        <input type="hidden" name="do" value="save_settings">

        <label>SMTP host</label>
        <input
          type="text"
          name="host"
          value="<?= e((string)($cfg['host'] ?? '')) ?>"
          placeholder="smtp.example.com"
          required
        >

        <label>SMTP port</label>
        <input
          type="number"
          name="port"
          min="1"
          max="65535"
          value="<?= e((string)($cfg['port'] ?? 587)) ?>"
          required
        >

        <label>Шифрование</label>
        <select name="encryption" required>
          <?php foreach (['tls', 'ssl', 'none'] as $mode): ?>
            <option
              value="<?= e($mode) ?>"
              <?= ($cfg['encryption'] ?? 'tls') === $mode ? 'selected' : '' ?>
            >
              <?= e($mode) ?>
            </option>
          <?php endforeach; ?>
        </select>

        <label>SMTP username</label>
        <input
          type="text"
          name="username"
          value="<?= e((string)($cfg['username'] ?? '')) ?>"
          autocomplete="username"
        >

        <label>SMTP password (пустое поле — оставить текущий)</label>
        <input
          type="password"
          name="password"
          value=""
          autocomplete="new-password"
        >

        <label>Адрес отправителя</label>
        <input
          type="email"
          name="from_email"
          value="<?= e((string)($cfg['from_email'] ?? '')) ?>"
          required
        >

        <label>Имя отправителя</label>
        <input
          type="text"
          name="from_name"
          value="<?= e((string)($cfg['from_name'] ?? '')) ?>"
        >

        <label>Получатели — адреса через запятую</label>
        <input
          type="text"
          name="to"
          value="<?= e((string)($cfg['to'] ?? '')) ?>"
          placeholder="admin@example.com"
          required
        >

        <label>Timeout, секунд</label>
        <input
          type="number"
          name="timeout"
          min="1"
          max="120"
          value="<?= e((string)($cfg['timeout'] ?? 15)) ?>"
          required
        >

        <p>
          <button type="submit" class="coru-btn">Изменить</button>
        </p>
      </form>
    </div>

    <div class="coru-card">
      <h3>Тестовая отправка</h3>

      <?php if ($result !== null): ?>
        <div class="coru-flash <?= $result === true ? '' : 'err' ?>">
          <?= $result === true ? 'Письмо отправлено.' : e((string)$result) ?>
        </div>
      <?php endif; ?>

      <form method="post" class="coru-form" style="max-width:600px">
        <?= coru_csrf() ?>
        <input type="hidden" name="do" value="send_test">

        <label>Кому отправить тест</label>
        <input
          type="email"
          name="test_to"
          value="<?= e((string)($cfg['to'] ?? '')) ?>"
          required
        >

        <label>Тема</label>
        <input type="text" name="subject" value="Coru test mail">

        <label>Текст письма</label>
        <textarea name="body">Test message from Coru CMS</textarea>

        <p><button type="submit" class="coru-btn">Отправить тест</button></p>
      </form>

      <h3>mail.log</h3>
      <pre style="max-height:300px;overflow:auto;font-size:12px"><?= e(
          is_file(__DIR__ . '/mail.log')
              ? implode('', array_slice(file(__DIR__ . '/mail.log'), -40))
              : '—'
      ) ?></pre>
    </div>

    <?php
    coru_admin_footer();
}
