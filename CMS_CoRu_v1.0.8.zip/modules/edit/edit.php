<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/coru/bootstrap.php';
require CORU_ROOT . '/adminpanel/inc/layout.php';

use Coru\App;
use Coru\Auth;
use Coru\Image;
use Coru\Pages;

Auth::checkCsrf();
$coru->auth->requireRole('editor');
$me = $coru->auth->user();

if (!$coru->modules->isEnabled('edit')) {
    App::flash('Module "edit" is disabled', 'err');
    App::redirect($coru->url('/adminpanel/modules.php'));
}

const CORU_MEDIA_EXT = [
    'pdf', 'zip', 'mp3', 'mp4', 'webm', 'ogg',
    'doc', 'docx', 'xls', 'xlsx', 'txt',
];

$picDir = CORU_ROOT . '/site/picture';
$mediaDir = CORU_ROOT . '/site/media';

foreach ([$picDir, $mediaDir] as $directory) {
    if (!is_dir($directory)) {
        mkdir($directory, 0775, true);
    }
}

/* Загрузка изображений и медиа из TinyMCE */
if (($_GET['action'] ?? '') === 'upload' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $file = $_FILES['file'] ?? null;

    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        http_response_code(400);
        exit(json_encode(['error' => e(mt('edit','file_dnt_upload'))], JSON_UNESCAPED_UNICODE));
    }

    if (!is_uploaded_file($file['tmp_name'])) {
        http_response_code(400);
        exit(json_encode(['error' => e(mt('edit','incorrect_file'))], JSON_UNESCAPED_UNICODE));
    }

    $name = Image::safeName((string)$file['name']);

    if (Image::isImage($file['tmp_name'])) {
        $destination = $picDir . '/' . $name;
        $url = $coru->url('/site/picture/' . $name);
    } else {
        $extension = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));

        if (!in_array($extension, CORU_MEDIA_EXT, true)) {
            http_response_code(415);
            exit(json_encode(['error' => e(mt('edit','typeisnt_allowed'))], JSON_UNESCAPED_UNICODE));
        }

        $destination = $mediaDir . '/' . $name;
        $url = $coru->url('/site/media/' . $name);
    }

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        http_response_code(500);
        exit(json_encode(['error' => e(mt('edit','er_image'))], JSON_UNESCAPED_UNICODE));
    }

    exit(json_encode(['location' => $url], JSON_UNESCAPED_SLASHES));
}

/* Загружаем страницу или подготавливаем новую */
$slugParam = (string)($_GET['page'] ?? '');
$page = $slugParam !== '' ? $coru->pages->get($slugParam) : null;

$page ??= [
    'slug'        => '',
    'title'       => '',
    'category'    => '',
    'keywords'    => '',
    'description' => '',
    'image'       => '',
    'date'        => date('Y-m-d'),
    'author'      => $me['login'] ?? '',
    'published'   => true,
    'content'     => '',
];

/* Удаление главной картинки отдельной кнопкой */
if (
    ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
    && ($_POST['do'] ?? '') === 'remove_image'
) {
    $slug = (string)($page['slug'] ?? '');

    if ($slug === '' || !$coru->pages->exists($slug)) {
        App::flash(mt('edit','save_page_first'), 'err');
        App::redirect('edit.php');
    }

    $image = (string)($page['image'] ?? '');
    $pictureRoot = realpath($picDir);

// Удаляем только существующий файл внутри /site/picture/
    if ($image !== '' && str_starts_with($image, '/site/picture/')) {
        $imagePath = realpath(CORU_ROOT . $image);

        if (
            $pictureRoot !== false
            && $imagePath !== false
            && str_starts_with(
                $imagePath,
                $pictureRoot . DIRECTORY_SEPARATOR
            )
            && is_file($imagePath)
        ) {
            unlink($imagePath);
        }
    }

    $page['image'] = '';
    $coru->pages->save(
        $slug,
        $page,
        (string)($page['content'] ?? '')
    );

    App::flash(mt('edit','del_page_first'));
    App::redirect('edit.php?page=' . rawurlencode($slug));
}

/* Сохранение страницы */
if (
    ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
    && ($_POST['do'] ?? '') === 'save'
) {
    $title = trim((string)($_POST['title'] ?? ''));

    if ($title === '') {
        App::flash(mt('edit','error') . ': ' . mt('edit','title'), 'err');
        App::redirect(
            'edit.php' . ($slugParam !== ''
                ? '?page=' . rawurlencode($slugParam)
                : '')
        );
    }

    if (mb_strlen($title) > 60) {
        App::flash(
            mt('edit','error') . ': '
            . mt('edit','title') . ' '
            . mt('edit','too_long', ['limit' => 60]),
            'err'
        );

        App::redirect(
            'edit.php' . ($slugParam !== ''
                ? '?page=' . rawurlencode($slugParam)
                : '')
        );
    }

    $slugInput = trim((string)($_POST['slug'] ?? ''));

    if ($slugInput !== '' && mb_strlen($slugInput) > 60) {
        App::flash(
            mt('edit','error') . ': slug '
            . mt('edit','too_long', ['limit' => 60]),
            'err'
        );

        App::redirect(
            'edit.php' . ($slugParam !== ''
                ? '?page=' . rawurlencode($slugParam)
                : '')
        );
    }

    $slug = Pages::slugify($slugInput !== '' ? $slugInput : $title);
    $oldSlug = (string)($page['slug'] ?? '');

    if ($oldSlug === '' && $coru->pages->exists($slug)) {
        $slug .= '-' . substr((string)time(), -4);
    }

    $categorySlug = (string)($_POST['category'] ?? '');

    $meta = [
        'title'       => $title,
        'category'    => $coru->categories->get($categorySlug)
            ? $categorySlug
            : '',
        'keywords'    => trim((string)($_POST['keywords'] ?? '')),
        'description' => trim((string)($_POST['description'] ?? '')),
        'image'       => (string)($page['image'] ?? ''),
        'date'        => preg_match(
            '/^\d{4}-\d{2}-\d{2}$/',
            (string)($_POST['date'] ?? '')
        )
            ? (string)$_POST['date']
            : date('Y-m-d'),
        'author'      => (string)($page['author'] ?? '') ?: (string)($me['login'] ?? ''),
        'published'   => isset($_POST['published']),
    ];

    /*
     * Загрузка/замена главной картинки.
     * Изображение обрезается до 800×400.
     */
    if (
        isset($_FILES['main_image'])
        && ($_FILES['main_image']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK
        && is_uploaded_file($_FILES['main_image']['tmp_name'])
    ) {
        $imagePath = $picDir . '/' . $slug . '-main.jpg';

        if (
            Image::isImage($_FILES['main_image']['tmp_name'])
            && Image::cropCover(
                $_FILES['main_image']['tmp_name'],
                $imagePath,
                800,
                400
            )
        ) {
            $meta['image'] = '/site/picture/' . $slug . '-main.jpg';
        } else {
            App::flash('Не удалось обработать главную картинку.', 'err');
        }
    }

    /*
     * Если slug изменился и картинка принадлежит этой странице,
     * переносим картинку на новое имя.
     */
    if ($oldSlug !== '' && $oldSlug !== $slug) {
        $oldImage = '/site/picture/' . $oldSlug . '-main.jpg';

        if (
            $meta['image'] === $oldImage
            && is_file($picDir . '/' . $oldSlug . '-main.jpg')
        ) {
            if (rename(
                $picDir . '/' . $oldSlug . '-main.jpg',
                $picDir . '/' . $slug . '-main.jpg'
            )) {
                $meta['image'] = '/site/picture/' . $slug . '-main.jpg';
            }
        }

        $oldPageFile = $coru->pages->file($oldSlug);

        if (is_file($oldPageFile)) {
            unlink($oldPageFile);
        }
    }

    $content = (string)($_POST['content'] ?? '');

    $coru->pages->save($slug, $meta, $content);
    $coru->fire('page.saved', [$slug, $meta]);

    App::flash(mt('edit','saved'));
    App::redirect('edit.php?page=' . rawurlencode($slug));
}

$csrf = Auth::csrf();

coru_admin_header(
    ($page['slug'] !== '' ? mt('edit','edit') : mt('edit','create'))
    . ': '
    . ($page['title'] !== '' ? $page['title'] : '…')
);
?>

<form method="post" enctype="multipart/form-data" class="coru-form" id="coruEdit">
  <?= coru_csrf() ?>

  <div class="coru-row">
    <div style="flex:3">
      <div class="coru-card">
        <label><?= e(mt('edit','title')) ?> (→ &lt;title&gt;)</label>

        <input
          type="text"
          name="title"
          value="<?= e($page['title']) ?>"
          required
          maxlength="60"
          id="titleInput"
        >
        <div class="char-counter" data-for="titleInput" data-limit="60"></div>

        <label>slug (URL)</label>
        <input
          type="text"
          name="slug"
          value="<?= e($page['slug']) ?>"
          placeholder="<?= e(mt('edit','auto_slug')) ?>"
          pattern="[a-z0-9\-]*"
          maxlength="60"
          id="slugInput"
        >
        <div class="char-counter" data-for="slugInput" data-limit="60"></div>

        <label><?= e(mt('edit','сontent')) ?></label>
        <textarea id="content" name="content"><?= e($page['content']) ?></textarea>
      </div>

      <div class="coru-card">
        <label><?= e(mt('edit','meta_keywords')) ?></label>
        <input
          type="text"
          name="keywords"
          value="<?= e($page['keywords']) ?>"
          placeholder="<?= e((string)$coru->config->get('site.keywords', '')) ?>"
        >

        <label><?= e(mt('edit','meta')) ?></label>
        <textarea name="description" style="min-height:70px"><?= e($page['description']) ?></textarea>

<p class="coru-muted">
    <?= e(mt('edit','empty_fields')) ?>
    <?= e(mt(
        'edit',
        $coru->config->get('site.use_global_meta')
            ? 'use_global_meta'
            : 'keep_empty'
    )) ?>
</p>
      </div>
    </div>

    <div style="flex:1;min-width:260px">
      <div class="coru-card">
        <label><?= e(mt('edit','category')) ?></label>
        <select name="category">
          <option value="">—</option>
          <?php foreach ($coru->categories->all() as $category): ?>
            <option
              value="<?= e($category['slug']) ?>"
              <?= $category['slug'] === $page['category'] ? 'selected' : '' ?>
            >
              <?= e($category['title']) ?>
            </option>
          <?php endforeach; ?>
        </select>

        <label><?= e(mt('edit','date')) ?></label>
        <input type="date" name="date" value="<?= e($page['date']) ?>">

        <p>
          <label>
            <input
              type="checkbox"
              name="published"
              <?= $page['published'] ? 'checked' : '' ?>
            >
            <?= e(mt('edit','published')) ?>
          </label>
        </p>

        <button
          type="submit"
          name="do"
          value="save"
          class="coru-btn"
          style="width:100%"
        >
          <?= e(mt('edit','save')) ?>
        </button>

        <?php if ($page['slug'] !== ''): ?>
          <p style="text-align:center">
            <a href="<?= e($coru->pageUrl($page['slug'])) ?>" target="_blank" rel="noopener">
             <?= e(mt('edit','page_view')) ?>
            </a>
          </p>
        <?php endif; ?>
      </div>

      <div class="coru-card">
        <label><?= e(mt('edit','image_crop')) ?></label>

        <?php if ($page['image'] !== ''): ?>
          <img
            src="<?= e($coru->url($page['image'])) ?>?v=<?= time() ?>"
            alt="<?= e($page['title']) ?>"
            style="width:100%;border-radius:6px;display:block;margin-bottom:8px"
          >

          <button
            type="submit"
            name="do"
            value="remove_image"
            class="coru-btn danger"
            formnovalidate
            onclick="return confirm('Удалить главную картинку?')"
          >
            <?= e(mt('edit','del_image')) ?>
          </button>
        <?php else: ?>
          <p class="coru-muted"><?= e(mt('edit','notmain_image')) ?></p>
        <?php endif; ?>

        <label for="main_image"><?= e(mt('edit','upload_image')) ?></label>
        <input
          id="main_image"
          type="file"
          name="main_image"
          accept="image/jpeg,image/png,image/gif,image/webp"
        >
      </div>
    </div>
  </div>
</form>

<script src="<?= e($coru->url('/modules/edit/tinymce/tinymce.min.js')) ?>"></script>

<script>
(function () {
  var contentField = document.getElementById('content');

  if (typeof tinymce === 'undefined') {
    if (contentField) contentField.style.minHeight = '400px';
    console.warn('TinyMCE not found: put tinymce.min.js into /modules/edit/tinymce/');
    return;
  }

  var csrf = <?= json_encode($csrf) ?>;
  var uploadUrl = <?= json_encode($coru->url('/modules/edit/edit.php?action=upload')) ?>;

  function upload(file) {
    var formData = new FormData();
    formData.append('file', file, file.name);
    formData.append('_csrf', csrf);

    return fetch(uploadUrl, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    })
      .then(function (response) {
        return response.json().then(function (json) {
          if (!response.ok) {
            throw new Error(json.error || '<?= e(mt('edit','err_upload')) ?>');
          }
          return json;
        });
      })
      .then(function (json) {
        if (!json.location) {
          throw new Error(json.error || '<?= e(mt('edit','noturl_file')) ?>');
        }
        return json.location;
      });
  }

  tinymce.init({
    selector: '#content',
    height: 540,
    license_key: 'gpl',
    plugins: 'image media link lists table code autolink anchor',
    toolbar: 'undo redo | blocks | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image media table | code',
    relative_urls: false,
    remove_script_host: false,
    convert_urls: true,
    automatic_uploads: true,

    images_upload_handler: function (blobInfo) {
      var imageFile = new File(
        [blobInfo.blob()],
        blobInfo.filename(),
        { type: blobInfo.blob().type }
      );

      return upload(imageFile);
    },

    file_picker_types: 'image media file',

    file_picker_callback: function (callback, value, meta) {
      var input = document.createElement('input');
      input.type = 'file';

      input.accept = meta.filetype === 'image'
        ? 'image/*'
        : (meta.filetype === 'media' ? 'video/*,audio/*' : '*/*');

      input.onchange = function () {
        var file = input.files && input.files[0];
        if (!file) return;

        upload(file)
          .then(function (url) {
            callback(url, { title: file.name });
          })
          .catch(function (error) {
            alert(error.message);
          });
      };

      input.click();
    }
  });
})();
</script>

<script>
(function () {
  function updateCounter(counter, current, limit) {
    counter.textContent = current + '/' + limit;

    if (current > limit) {
      counter.style.color = '#d9534f';
    } else if (current > limit * 0.9) {
      counter.style.color = '#f0ad4e';
    } else {
      counter.style.color = '#6c757d';
    }
  }

  document.querySelectorAll('.char-counter').forEach(function (counter) {
    var inputId = counter.getAttribute('data-for');
    var limit = parseInt(counter.getAttribute('data-limit'), 10);
    var input = document.getElementById(inputId);

    if (!input || !Number.isFinite(limit)) return;

    updateCounter(counter, input.value.length, limit);

    input.addEventListener('input', function () {
      updateCounter(counter, this.value.length, limit);
    });
  });
})();
</script>

<?php coru_admin_footer(); ?>