<?php
declare(strict_types=1);

final class CoruGoods
{
    public static function load(): array
    {
        $d = Coru\Yaml::load(__DIR__ . '/goods.yaml');
        $items = [];
        foreach ($d['items'] ?? [] as $i) {
            if (!isset($i['id'])) continue;
            $items[(int)$i['id']] = ['id' => (int)$i['id'], 'name' => (string)($i['name'] ?? ''), 'price' => (float)($i['price'] ?? 0),
                                     'unit' => (string)($i['unit'] ?? 'шт'), 'image' => (string)($i['image'] ?? '')];
        }
        return ['currency' => (string)($d['currency'] ?? '₽'), 'items' => $items];
    }

    public static function save(array $items, string $currency): void
    {
        Coru\Yaml::save(__DIR__ . '/goods.yaml', ['currency' => $currency, 'items' => array_values($items)]);
    }

    public static function &cart(): array
    {
        $_SESSION['coru_cart'] ??= [];
        return $_SESSION['coru_cart'];
    }

    public static function applyQty(array $qty, array $items, bool $merge): void
    {
        $cart = &self::cart();
        foreach ($qty as $id => $q) {
            $id = (int)$id; $q = max(0, min(999, (int)$q));
            if (!isset($items[$id])) continue;
            if ($q === 0) { if (!$merge) unset($cart[$id]); continue; }
            $cart[$id] = $q;
        }
    }

    public static function rows(array $items): array
    {
        $rows = [];
        foreach (self::cart() as $id => $q) {
            if (!isset($items[$id])) continue;
            $g = $items[$id];
            $rows[] = $g + ['qty' => $q, 'sum' => round($g['price'] * $q, 2)];
        }
        return $rows;
    }

    public static function placeOrder(array $rows, array $customer, string $currency): string
    {
        $dir = __DIR__ . '/orders';
        is_dir($dir) || mkdir($dir, 0775, true);
        $id = date('Ymd-His') . '-' . substr(bin2hex(random_bytes(2)), 0, 4);
        $total = array_sum(array_column($rows, 'sum'));
        Coru\Yaml::save("$dir/$id.yaml", ['id' => $id, 'date' => date('c'), 'customer' => $customer, 'items' => $rows, 'total' => $total, 'currency' => $currency, 'status' => 'new']);
        if (function_exists('coru_mail')) {
            $cfg = Coru\Yaml::load(dirname(__DIR__) . '/mail/mail.yaml');
            $txt = "Order #$id\n\n";
            foreach ($rows as $r) $txt .= "{$r['name']} × {$r['qty']} = {$r['sum']} $currency\n";
            $txt .= "\nTotal: $total $currency\n\n" . print_r($customer, true);
            if (!empty($cfg['to'])) coru_mail((string)$cfg['to'], "New order #$id", $txt, false, (string)$customer['email']);
            if (!empty($customer['email'])) coru_mail((string)$customer['email'], "Your order #$id", $txt);
        }
        return $id;
    }

    public static function orders(): array
    {
        $out = [];
        foreach (array_reverse(glob(__DIR__ . '/orders/*.yaml') ?: []) as $f) $out[] = Coru\Yaml::load($f);
        return $out;
    }
}

if (isset($coru) && $coru instanceof Coru\App && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== __FILE__) {
    $coru->route('goods', function (Coru\App $coru, string $path): string {
        $twig = $coru->view()->twig();
        $loader = $twig->getLoader();

        if ($loader instanceof Twig\Loader\FilesystemLoader) {
            $loader->addPath(__DIR__ . '/templates', 'goods');
        }

        $data  = CoruGoods::load();
        $items = $data['items'];
        $csrf  = Coru\Auth::csrf();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Coru\Auth::checkCsrf();
        }

// Личный кабинет: показываем только заказы текущего пользователя.
        if ($path === 'goods/orders') {
            $user = $coru->auth->user();

            if (!$user) {
                Coru\App::redirect($coru->url('/adminpanel/login.php'));
            }

            $myOrders = array_values(array_filter(
                CoruGoods::orders(),
                static fn(array $order): bool =>
                    ($order['customer']['owner_login'] ?? '') === $user['login']
            ));

            return $twig->render('@goods/my-orders.html.twig', [
                'orders' => $myOrders,
            ]);
        }
// проверка на роли и доступ по меню
if ($path === 'goods/orders') {
    $user = $coru->auth->user();

    if (!$user) {
        Coru\App::redirect($coru->url('/adminpanel/login.php'));
    }

    $login = (string)($user['login'] ?? '');

    $myOrders = array_values(array_filter(
        CoruGoods::orders(),
        static fn(array $order): bool =>
            (string)($order['customer']['owner_login'] ?? '') === $login
    ));

    return $twig->render('@goods/my-orders.html.twig', [
        'orders' => $myOrders,
    ]);
}

// Корзина и оформление заказа.
        if ($path === 'goods/cart') {
            $error = '';
            $order = '';
            $do = (string)($_POST['do'] ?? '');

            if ($do === 'update' || $do === 'checkout') {
                CoruGoods::applyQty($_POST['qty'] ?? [], $items, false);
            }

            if (str_starts_with($do, 'remove:')) {
                $cart = &CoruGoods::cart();
                unset($cart[(int)substr($do, 7)]);
            }

            $rows = CoruGoods::rows($items);

            if ($do === 'checkout') {
                $user = $coru->auth->user();

                $customer = [
                    'name'        => trim(strip_tags((string)($_POST['name'] ?? ''))),
                    'email'       => filter_var(
                        (string)($_POST['email'] ?? ''),
                        FILTER_VALIDATE_EMAIL
                    ) ?: '',
                    'phone'       => trim(strip_tags((string)($_POST['phone'] ?? ''))),
                    'address'     => trim(strip_tags((string)($_POST['address'] ?? ''))),
                    'owner_login' => (string)($user['login'] ?? ''),
                    'ip'          => $_SERVER['REMOTE_ADDR'] ?? '',
                ];

                if (!$user) {
                    $error = 'Войдите в аккаунт перед оформлением заказа или пройдите регистрацию.';
                } elseif (!$rows) {
                    $error = $coru->t('goods.empty');
                } elseif ($customer['name'] === '' || $customer['email'] === '') {
                    $error = $coru->mt('goods','fill_fields');
                } else {
                    $order = CoruGoods::placeOrder($rows, $customer, $data['currency']);
                    $_SESSION['coru_cart'] = [];
                }
            }

            return $twig->render('@goods/cart.html.twig', [
                'rows'     => $rows,
                'total'    => array_sum(array_column($rows, 'sum')),
                'currency' => $data['currency'],
                'csrf'     => $csrf,
                'error'    => $error,
                'order'    => $order,
            ]);
        }

        // Страница товаров и добавление количества в корзину.
        $added = false;

        if (($_POST['do'] ?? '') === 'clear_cart') {
            $_SESSION['coru_cart'] = [];
        } elseif (($_POST['do'] ?? '') === 'add') {
            $id = filter_var($_POST['add_id'] ?? null, FILTER_VALIDATE_INT);

            if ($id !== false && isset($items[$id])) {
                $submittedQty = $_POST['qty'][$id] ?? null;
                $qty = filter_var(
                    $submittedQty,
                    FILTER_VALIDATE_INT,
                    ['options' => ['min_range' => 1, 'max_range' => 999]]
                );

                if ($qty !== false) {
                    $cart = &CoruGoods::cart();
                    $cart[$id] = min(999, (int)($cart[$id] ?? 0) + $qty);
                    $added = true;
                }
            }
        }

        return $twig->render('@goods/goods.html.twig', [
            'items'     => array_slice($items, 0, 10, true),
            'currency'  => $data['currency'],
            'cart'      => CoruGoods::cart(),
            'cart_count'=> array_sum(CoruGoods::cart()),
            'csrf'      => $csrf,
            'added'     => $added,
        ]);
    });

    return;
}


if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    require dirname(__DIR__, 2) . '/adminpanel/inc/boot.php';
    require CORU_ROOT . '/adminpanel/inc/layout.php';

    $data = CoruGoods::load();
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'save') {
        $items = [];
        for ($i = 1; $i <= 10; $i++) {
            $items[$i] = ['id' => $i, 'name' => trim((string)($_POST['name'][$i] ?? "Товар $i")), 'price' => (float)str_replace(',', '.', (string)($_POST['price'][$i] ?? 0)),
                          'unit' => trim((string)($_POST['unit'][$i] ?? 'шт')), 'image' => trim((string)($_POST['image'][$i] ?? ''))];
        }

CoruGoods::save(
    $items,
    trim((string)($_POST['currency'] ?? ''))
        ?: mt('goods', 'default_currency')
);

        Coru\App::flash(mt('goods','saved'));
        Coru\App::redirect('goods.php');
    }
    coru_admin_header(e(mt('goods','table_goods')));
    ?>
    <form method="post" class="coru-card coru-form"><?= coru_csrf() ?><input type="hidden" name="do" value="save">
      <label><?= e(mt('goods', 'currency')) ?></label>
	<input type="text" name="currency" value="<?= e($data['currency']) ?>" style="max-width:120px">
      <table class="coru-table" style="margin-top:12px">
        <tr>
	 <th>№</th>
	 <th><?= e(mt('goods','namegoods')) ?></th>
	 <th><?= e(mt('goods','price')) ?></th>
	 <th><?= e(mt('goods','unit')) ?></th>
         <th>URL as: <strong>/site/picture/...</strong></th>
	</tr>
        <?php for ($i = 1; $i <= 10; $i++): $g = $data['items'][$i] ?? ['name' => "Товар $i", 'price' => 0, 'unit' => 'шт', 'image' => '']; ?>
        <tr><td><?= $i ?></td>
          <td><input type="text" name="name[<?= $i ?>]" value="<?= e($g['name']) ?>"></td>
          <td><input type="text" name="price[<?= $i ?>]" value="<?= e((string)$g['price']) ?>" style="width:110px"></td>
          <td><input type="text" name="unit[<?= $i ?>]" value="<?= e($g['unit']) ?>" style="width:90px"></td>
          <td><input type="text" name="image[<?= $i ?>]" value="<?= e($g['image']) ?>"></td></tr>
        <?php endfor; ?>
      </table>
        <p><button class="coru-btn"><?= e(mt('goods','save')) ?>
	   </button> <a class="coru-btn sec" target="_blank" href="<?= e($coru->url('?p=goods')) ?>"><?= e(mt('goods', 'link')) ?></a>
	</p>
    </form>

<?php
coru_admin_footer();
}