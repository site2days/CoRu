<?php
declare(strict_types=1);

$coruMinRole = 'admin';

require dirname(__DIR__, 2) . '/adminpanel/inc/boot.php';
require CORU_ROOT . '/adminpanel/inc/layout.php';

use Coru\App;
use Coru\Yaml;

$allowedStatuses = ['new', 'done', 'on delivery', 'in processing'];

$statusLabels = [
    'new'           => t('orders.status.new'),
    'done'          => t('orders.status.done'),
    'on delivery'   => t('orders.status.on_delivery'),
    'in processing' => t('orders.status.in_processing'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'set_status') {
    $orderId = (string)($_POST['order_id'] ?? '');
    $status  = (string)($_POST['status'] ?? '');

    if (!in_array($status, $allowedStatuses, true)) {
        App::flash('Недопустимый статус заказа.', 'err');
        App::redirect('orders.php');
    }

    // Ищем файл заказа только по его внутреннему ID.
    $updated = false;

    foreach (glob(__DIR__ . '/orders/*.yaml') ?: [] as $orderFile) {
        $order = Yaml::load($orderFile);

        if (($order['id'] ?? '') === $orderId) {
            $order['status'] = $status;
            Yaml::save($orderFile, $order);
            $updated = true;
            break;
        }
    }

    App::flash(
        mt('goods', $updated ? 'order_status_updated' : 'order_not_found'),
        $updated ? 'ok' : 'err'
    );

    App::redirect(
        'orders.php' . (!empty($_POST['q'])
            ? '?q=' . rawurlencode((string)$_POST['q'])
            : '')
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete_order') {
    $orderId = trim((string)($_POST['order_id'] ?? ''));
    $query = trim((string)($_POST['q'] ?? ''));
    $deleted = false;

    // Сверяем ID с данными заказов, не строим путь из POST.
    foreach (glob(__DIR__ . '/orders/*.yaml') ?: [] as $orderFile) {
        $order = Yaml::load($orderFile);

        if ((string)($order['id'] ?? '') === $orderId) {
            $deleted = is_file($orderFile) && unlink($orderFile);
            break;
        }
    }

    App::flash(
        $deleted
            ? mt('goods', 'order_deleted')
            : mt('goods', 'order_delete_failed'),
        $deleted ? 'ok' : 'err'
    );

    App::redirect(
        'orders.php' . ($query !== '' ? '?q=' . rawurlencode($query) : '')
    );
}

$q = trim((string)($_GET['q'] ?? ''));
$allOrders = CoruGoods::orders();

/*
 * Поиск только по данным заказа и покупателя.
 * Поле items намеренно не используется.
 */
$orders = array_values(array_filter($allOrders, static function (array $order) use ($q): bool {
    if ($q === '') {
        return true;
    }

    $customer = is_array($order['customer'] ?? null) ? $order['customer'] : [];
    $searchable = [
        $order['id'] ?? '',
        $order['date'] ?? '',
        $order['status'] ?? '',
        $customer['name'] ?? '',
        $customer['email'] ?? '',
        $customer['phone'] ?? '',
        $customer['address'] ?? '',
    ];

    foreach ($searchable as $value) {
        if (stripos((string)$value, $q) !== false) {
            return true;
        }
    }

    return false;
}));

coru_admin_header(e(mt('goods', 'orders')));
?>

<div class="coru-card">
  <form method="get" class="coru-form coru-orders-search">
    <label for="coru-order-search"><?= e(mt('goods', 'find_orders')) ?></label>

    <div class="coru-orders-search-row">
      <input
        id="coru-order-search"
        type="search"
        name="q"
        value="<?= e($q) ?>"
        placeholder="<?= e(mt('goods', 'find_id')) ?>"
      >
      <button class="coru-btn" type="submit"><?= e(mt('goods', 'find')) ?></button>

      <?php if ($q !== ''): ?>
        <a class="coru-btn sec" href="orders.php">
          <?= e(mt('goods', 'reset')) ?>
        </a>
      <?php endif; ?>
    </div>

    <p class="coru-muted">
      <?= e(mt('goods', 'find_in_orders')) ?><?= count($orders) ?>
    </p>
  </form>
</div>

<div class="coru-card">
  <h3><?= e(mt('goods', 'list_orders')) ?></h3>

  <table class="coru-table coru-orders-table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Статус</th>
        <th>Дата</th>
        <th>Покупатель</th>
        <th>Итого</th>
      </tr>
    </thead>

    <tbody>
      <?php if (!$orders): ?>
        <tr>
          <td colspan="5" class="coru-muted">Заказы не найдены.</td>
        </tr>
      <?php else: ?>
        <?php foreach ($orders as $index => $o): ?>
          <?php $detailsId = 'coru-order-details-' . $index; ?>

          <tr
            class="coru-order-row"
            tabindex="0"
            role="button"
            aria-expanded="false"
            aria-controls="<?= e($detailsId) ?>"
            data-details="<?= e($detailsId) ?>"
          >
            <td><?= e((string)($o['id'] ?? '')) ?></td>
            <td>
              <span class="coru-badge">
                <?= e($statusLabels[$o['status'] ?? 'new'] ?? (string)($o['status'] ?? 'new')) ?>
              </span>
            </td>
            <td><?= e((string)($o['date'] ?? '')) ?></td>
            <td>
              <?= e((string)($o['customer']['name'] ?? '')) ?> ·
              <?= e((string)($o['customer']['email'] ?? '')) ?> ·
              <?= e((string)($o['customer']['phone'] ?? '')) ?>
            </td>
            <td>
              <?= e((string)($o['total'] ?? '')) ?>
              <?= e((string)($o['currency'] ?? '')) ?>
            </td>
          </tr>

          <tr id="<?= e($detailsId) ?>" class="coru-order-details" hidden>
            <td colspan="4">
              <section class="coru-order-detail-card">
                <h4>
                  Заказ #<?= e((string)($o['id'] ?? '')) ?>
                  <span class="coru-badge">
                    <?= e($statusLabels[$o['status'] ?? 'new'] ?? (string)($o['status'] ?? 'new')) ?>
                  </span>
                </h4>

                <div class="coru-order-actions">
                  <form method="post" class="coru-order-status-form">
                    <?= \Coru\Auth::csrfField() ?>
                    <input type="hidden" name="do" value="set_status">
                    <input
                      type="hidden"
                      name="order_id"
                      value="<?= e((string)($o['id'] ?? '')) ?>"
                    >
                    <input type="hidden" name="q" value="<?= e($q) ?>">

                    <label for="status-<?= e((string)($o['id'] ?? '')) ?>">
                      <?= e(mt('goods', 'order_status')) ?>
                    </label>

                    <select
                      id="status-<?= e((string)($o['id'] ?? '')) ?>"
                      name="status"
                    >
                      <?php foreach ($allowedStatuses as $status): ?>
                        <option
                          value="<?= e($status) ?>"
                          <?= ($o['status'] ?? 'new') === $status ? 'selected' : '' ?>
                        >
                          <?= e($statusLabels[$status] ?? $status) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>

                    <button type="submit" class="coru-btn sm">
                      <?= e(mt('goods', 'save_status')) ?>
                    </button>
                  </form>

                  <form
                    method="post"
                    class="coru-order-delete-form"
                    data-confirm="<?= e(mt('goods','order_delete_confirm')) ?>"
                    onsubmit="return confirm(this.dataset.confirm)"
                  >
                    <?= \Coru\Auth::csrfField() ?>
                    <input type="hidden" name="do" value="delete_order">
                    <input
                      type="hidden"
                      name="order_id"
                      value="<?= e((string)($o['id'] ?? '')) ?>"
                    >
                    <input type="hidden" name="q" value="<?= e($q) ?>">

                    <button type="submit" class="coru-btn danger">
                     <?= e(mt('goods','order_delete')) ?>
                    </button>
                  </form>
                </div>

                <p>
                  <?= e(mt('goods', 'buyer')) ?>
                  <?= e((string)($o['customer']['name'] ?? '')) ?><br>
                  E-mail: <?= e((string)($o['customer']['email'] ?? '')) ?><br>
                  <?= e(mt('goods', 'phone')) ?>
                  <?= e((string)($o['customer']['phone'] ?? '')) ?><br>
                  <?= e(mt('goods', 'address')) ?>
                  <?= e((string)($o['customer']['address'] ?? '')) ?>
                </p>

                <table class="coru-table">
                  <thead>
                    <tr>
                      <th>Товар</th>
                      <th>Цена</th>
                      <th>Количество</th>
                      <th>Сумма</th>
                    </tr>
                  </thead>

                  <tbody>
                    <?php foreach (($o['items'] ?? []) as $item): ?>
                      <?php if (!is_array($item)) continue; ?>
                      <tr>
                        <td><?= e((string)($item['name'] ?? '')) ?></td>
                        <td>
                          <?= e((string)($item['price'] ?? '0')) ?>
                          <?= e((string)($o['currency'] ?? '')) ?>
                        </td>
                        <td><?= e((string)($item['qty'] ?? '0')) ?></td>
                        <td>
                          <?= e((string)($item['sum'] ?? '0')) ?>
                          <?= e((string)($o['currency'] ?? '')) ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>

                  <tfoot>
                    <tr>
                      <th colspan="3">Итого</th>
                      <th>
                        <?= e((string)($o['total'] ?? '0')) ?>
                        <?= e((string)($o['currency'] ?? '')) ?>
                      </th>
                    </tr>
                  </tfoot>
                </table>
              </section>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<style>
.coru-orders-search-row {
  display: flex;
  align-items: end;
  gap: 8px;
  flex-wrap: wrap;
}

.coru-orders-search-row input[type="search"] {
  flex: 1;
  min-width: 220px;
  padding: 8px 10px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font: inherit;
}

.coru-order-row {
  cursor: pointer;
}

.coru-order-row:hover,
.coru-order-row:focus {
  background: #f3f6fb;
  outline: none;
}

.coru-order-details > td {
  padding: 0;
  background: #f8fafc;
}

.coru-order-detail-card {
  padding: 18px;
  border-bottom: 1px solid #e5e7eb;
}

.coru-order-actions {
  display: flex;
  align-items: flex-end;
  gap: 10px;
  flex-wrap: wrap;
  margin: 12px 0 20px;
}

.coru-order-status-form {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  flex-wrap: wrap;
  margin: 0;
}

.coru-order-status-form label {
  margin-right: 4px;
}

.coru-order-status-form select {
  padding: 6px 8px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font: inherit;
}

.coru-order-delete-form {
  margin: 0;
}
</style>

<script>
document.querySelectorAll('.coru-order-row').forEach(function (row) {
  function toggleDetails() {
    var details = document.getElementById(row.dataset.details);
    if (!details) return;

    var isOpen = !details.hidden;
    details.hidden = isOpen;
    row.setAttribute('aria-expanded', String(!isOpen));
  }

  row.addEventListener('click', toggleDetails);
  row.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      toggleDetails();
    }
  });
});
</script>

<?php coru_admin_footer(); ?>