<?php
/**
 * Coru module: chat — общий чат + личные сообщения по нику, список online.
 * Хранение: /modules/chat/data/messages.json, online.json. Фронт: /?p=chat, API: /?p=chat/api
 */
declare(strict_types=1);

final class CoruChat
{
    public const ONLINE_TTL = 60;   // сек
    public const KEEP       = 2000;  // сообщений в истории

    private static function file(string $n): string
    {
        $dir = __DIR__ . '/data';
        is_dir($dir) || mkdir($dir, 0775, true);
        return "$dir/$n.json";
    }
/* должны оставновиться повторы беконечные */
public static function history(int $limit = 100): array
{
    $messages = self::read('messages');
    return array_slice(array_reverse($messages), 0, $limit);
}
/* должны оставновиться повторы беконечные */
    private static function read(string $n): array
    {
        $f = self::file($n);
        return is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
    }

    private static function write(string $n, array $d): void
    {
        file_put_contents(self::file($n), json_encode($d, JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    public static function touch(string $nick): array
    {
        $on = self::read('online');
        $on[$nick] = time();
        $on = array_filter($on, fn($t) => $t > time() - self::ONLINE_TTL);
        self::write('online', $on);
        $names = array_keys($on);
        sort($names);
        return $names;
    }

    public static function send(string $from, string $to, string $text): true|string
    {
        $text = trim($text);
        if ($text === '' || mb_strlen($text) > 1000) return 'empty or too long';
        $to = Coru\Auth::cleanLogin($to);
        if ($to !== '' && $to !== $from && !Coru\App::instance()->auth->findUser($to)) return "user '$to' not found";
        if ($to === $from) $to = '';
        $msgs = self::read('messages');
        $id = ($msgs ? max(array_column($msgs, 'id')) : 0) + 1;
        $msgs[] = ['id' => $id, 'time' => date('H:i'), 'ts' => time(), 'from' => $from, 'to' => $to, 'text' => $text];
        if (count($msgs) > self::KEEP) $msgs = array_slice($msgs, -self::KEEP);
        self::write('messages', $msgs);
        return true;
    }

    public static function poll(string $me, int $since): array
    {
        return array_values(array_filter(self::read('messages'),
            fn($m) => $m['id'] > $since && ($m['to'] === '' || $m['to'] === $me || $m['from'] === $me)));
    }

    public static function clear(): void
    {
        self::write('messages', []);
    }
}

/* ---------- маршруты (файл подключён ядром через autoload: true) ---------- */
if (isset($coru) && $coru instanceof Coru\App && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== __FILE__) {
    $coru->route('chat', function (Coru\App $coru, string $path): string {
        $user = $coru->auth->user();
        if ($path === 'chat/api') {
            header('Content-Type: application/json; charset=utf-8');
            if (!$user) { http_response_code(401); return json_encode(['error' => 'login required']); }
            $me = $user['login'];
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                Coru\Auth::checkCsrf();
                $r = CoruChat::send($me, (string)($_POST['to'] ?? ''), (string)($_POST['text'] ?? ''));
                return json_encode($r === true ? ['ok' => true] : ['error' => $r], JSON_UNESCAPED_UNICODE);
            }
            $online = CoruChat::touch($me);
            return json_encode(['messages' => CoruChat::poll($me, (int)($_GET['since'] ?? 0)), 'online' => $online], JSON_UNESCAPED_UNICODE);
        }
        $twig = $coru->view()->twig();
        $loader = $twig->getLoader();
        if ($loader instanceof Twig\Loader\FilesystemLoader) $loader->addPath(__DIR__ . '/templates', 'chat');
        return $twig->render('@chat/chat.html.twig', ['csrf' => Coru\Auth::csrf()]);
    });
    return;
}

/* ---------- админка модуля (файл открыт напрямую: /modules/chat/chat.php) ---------- */
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $coruMinRole = 'admin';
    require dirname(__DIR__, 2) . '/adminpanel/inc/boot.php';
    require CORU_ROOT . '/adminpanel/inc/layout.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'clear') {
        CoruChat::clear();
        Coru\App::flash(mt('chat','delete'));
        Coru\App::redirect('chat.php');
    }

//    $msgs = array_reverse(CoruChat::poll('', 0)); повтор остановить
    $msgs = CoruChat::history(100);
    coru_admin_header(e(mt('chat','chat_history')));
    ?>
    <div class="coru-card">
      <p><a class="coru-btn sec" target="_blank" href="<?= e($coru->url('?p=chat')) ?>">↗  <?= e(mt('chat','to_chat')) ?></a>
	<form method="post" class="coru-inline" onsubmit="return confirm('?')"><?= coru_csrf() ?>
	   <input type="hidden" name="do" value="clear"><button class="coru-btn danger"><?= e(mt('chat','сlear_history')) ?></button>
	</form></p>
      <table class="coru-table">
      <tr>
	<th>#</th>
	<th><?= e(mt('chat','time')) ?></th>
	<th><?= e(mt('chat','from')) ?></th>
	<th><?= e(mt('chat','to')) ?></th>
	<th><?= e(mt('chat','text')) ?></th>
      </tr>
      <?php foreach (array_slice($msgs, 0, 100) as $m): ?>
      <tr><td><?= (int)$m['id'] ?></td><td><?= e(date('Y-m-d H:i', (int)$m['ts'])) ?></td><td><?= e($m['from']) ?></td><td><?= e($m['to'] ?: '*') ?></td><td><?= e($m['text']) ?></td></tr>
      <?php endforeach; ?></table>
    </div>
    <?php
    coru_admin_footer();
}