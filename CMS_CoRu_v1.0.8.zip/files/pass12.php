<?php
declare(strict_types=1);

// Temporary password-hash generator. Does not modify adm.yaml.
ini_set('display_errors', '0');
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");

session_start([
    'use_strict_mode' => 1,
    'cookie_httponly' => true,
    'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'cookie_samesite' => 'Strict',
]);

if (empty($_SESSION['coru_hash_csrf'])) {
    $_SESSION['coru_hash_csrf'] = bin2hex(random_bytes(32));
}

$error = '';
$hash = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = $_POST['csrf'] ?? null;
    $password = $_POST['password'] ?? null;

    if (!is_string($token) || !hash_equals($_SESSION['coru_hash_csrf'], $token)) {
        http_response_code(403);
        $error = 'Сессия формы устарела. Обновите страницу и повторите ввод.';
    } elseif (!is_string($password) || strlen($password) < 12 || strlen($password) > 72) {
        $error = 'Пароль должен содержать от 12 до 72 байт.';
    } elseif (strpos($password, "\0") !== false) {
        $error = 'Пароль не должен содержать нулевые байты.';
    } else {
        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            if (!is_string($hash) || $hash === '') {
                throw new RuntimeException('Hash generation failed');
            }
            $_SESSION['coru_hash_csrf'] = bin2hex(random_bytes(32));
        } catch (Throwable $exception) {
            $error = 'Не удалось создать хеш. Проверьте поддержку password_hash() на хостинге.';
        }
    }
    unset($password, $_POST['password']);
}

function coru_escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Coru — генератор хеша пароля</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f1f5f9;color:#182238;font:16px/1.6 system-ui,sans-serif;padding:40px 16px}main{max-width:720px;margin:auto;background:white;border:1px solid #dde4ed;border-radius:18px;padding:32px}h1{font-size:26px;line-height:1.3;margin:0 0 16px}label{display:block;font-weight:650;margin-bottom:8px}input,textarea{width:100%;border:1px solid #aab7c7;border-radius:8px;padding:12px;font:inherit}textarea{font:14px/1.6 monospace;resize:vertical;overflow-wrap:anywhere}button{border:0;border-radius:8px;background:#244cce;color:white;padding:12px 20px;font:inherit;cursor:pointer;margin-top:16px}.note{color:#526179;font-size:14px}.error{background:#fff0f0;color:#9b2020;padding:12px;border-radius:8px}.result{margin-top:28px}code{overflow-wrap:anywhere}.warning{border-left:4px solid #d58b1e;padding-left:14px}
</style>
</head>
<body>
<main>
<h1>Генератор хеша пароля Coru</h1>
<p>Введите пароль. PHP создаст хеш через <code>password_hash($password, PASSWORD_DEFAULT)</code>. Файл <code>adm.yaml</code> не изменяется.</p>
<p class="warning">Используйте только HTTPS. После завершения удалите этот PHP-файл с хостинга.</p>
<?php if ($error !== ''): ?>
<p class="error" role="alert"><?= coru_escape($error) ?></p>
<?php endif; ?>
<form method="post" action="" accept-charset="UTF-8">
<input type="hidden" name="csrf" value="<?= coru_escape($_SESSION['coru_hash_csrf']) ?>">
<label for="password">Пароль администратора</label>
<input type="password" id="password" name="password" autocomplete="new-password" required spellcheck="false">
<p class="note">От 12 до 72 байт, не обязательно символов: кириллица и эмодзи занимают несколько байт в UTF-8. Пробелы в начале и конце сохраняются. Пароль не подставляется обратно в форму.</p>
<button type="submit">Создать хеш</button>
</form>
<?php if ($hash !== ''): ?>
<section class="result">
<h2>Хеш готов</h2>
<label for="hash">Скопируйте значение целиком</label>
<textarea id="hash" rows="3" readonly spellcheck="false"><?= coru_escape($hash) ?></textarea>
<p>Вставьте его в <code>adminpanel/adm.yaml</code>. Если учётная запись уже существует, замените только поле <code>password_hash</code>. Для новой записи пример:</p>
<textarea rows="5" readonly spellcheck="false" aria-label="Пример adm.yaml"><?= coru_escape("login: admin\npassword_hash: '" . $hash . "'\nrole: dmin\nstatus: active") ?></textarea>
<p class="note">При входе используйте исходный пароль, а не хеш. Логин можно заменить своим: 3–40 символов из a–z, 0–9, _ и -. YAML-файл должен быть недоступен для скачивания через веб-сервер.</p>
</section>
<?php endif; ?>
</main>
</body>
</html>
