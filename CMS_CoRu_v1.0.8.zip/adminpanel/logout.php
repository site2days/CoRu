<?php
declare(strict_types=1);

require dirname(__DIR__) . '/coru/bootstrap.php';
$coru->auth->logout();
Coru\App::redirect($coru->url('/'));
/** Coru\App::redirect($coru->url('/adminpanel/login.php')); выход на логирование */