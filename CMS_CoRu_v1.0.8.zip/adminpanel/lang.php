<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

$langs = $coru->lang->available();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedLang = (string)($_POST['lang'] ?? '');

    if (in_array($selectedLang, $langs, true)) {
        $_SESSION['coru_lang'] = $selectedLang;
        App::flash(t('admin.saved'));
        App::redirect('lang.php');
    }

    App::flash(t('admin.error'), 'err');
    App::redirect('lang.php');
}

coru_admin_header(t('admin.lang'));
?>

<div class="coru-card coru-form">
  <form method="post" class="coru-row" style="align-items:flex-end">
    <?= coru_csrf() ?>

    <div>
      <label for="coru-interface-language">
        <?= e(t('admin.interfacelang')) ?>
      </label>

      <select id="coru-interface-language" name="lang" required>
        <?php foreach ($langs as $language): ?>
          <option
            value="<?= e($language) ?>"
            <?= $language === $coru->lang->code ? 'selected' : '' ?>
          >
            <?= e(strtoupper($language)) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="flex:0">
      <button type="submit" class="coru-btn">
        <?= e(t('admin.save')) ?>
      </button>
    </div>
  </form>
</div>

<?php coru_admin_footer(); ?>