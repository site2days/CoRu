<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/coru/bootstrap.php';

use Coru\Auth;
use Coru\Module;
use Coru\Yaml;

Auth::requireRole('admin');

const CORU_MODULES_STATE = CORU_USERS . '/modules.yaml';

/** Состояние модулей: включён/выключен, /adminpanel/data/modules.yaml */
function coru_modules_state(): array
{
    $data = Yaml::parseFile(CORU_MODULES_STATE);
    $state = $data['modules'] ?? [];
    return is_array($state) ? $state : [];
}

function coru_modules_save(array $state): bool
{
    return Yaml::dumpFile(CORU_MODULES_STATE, ['modules' => $state]);
}

$notice = null;

/* ─────────────── обработка действий ─────────────── */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::csrfOk($_POST['coru_csrf'] ?? null)) {
    $slug = preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) ($_POST['slug'] ?? ''))) ?? '';
    $act  = (string) ($_POST['act'] ?? '');
    $state = coru_modules_state();

    if ($slug === '') {
        $notice = ['type' => 'error', 'text' => 'Не указан slug модуля.'];
    } elseif ($act === 'toggle') {
        $current = $state[$slug] ?? [];
        $enabled = (bool) ($current['enabled'] ?? true);

        $state[$slug] = [
            'enabled'  => !$enabled,
            'roles'    => (array) ($current['roles'] ?? []),
            'toggled'  => date('c'),
        ];

        coru_modules_save($state);
        $notice = ['type' => 'ok', 'text' => $enabled
            ? "Модуль {$slug} отключён."
            : "Модуль {$slug} включён."];
    } elseif ($act === 'roles') {
        $roles = array_values(array_intersect(
            (array) ($_POST['roles'] ?? []),
            Auth::ROLES
        ));

        $current = $state[$slug] ?? [];
        $state[$slug] = [
            'enabled'  => (bool) ($current['enabled'] ?? true),
            'roles'    => $roles === [] ? ['admin'] : $roles,
            'toggled'  => date('c'),
        ];

        coru_modules_save($state);
        $notice = ['type' => 'ok', 'text' => "Права модуля {$slug} обновлены."];
    }

    header('Location: plugins.php');
    $_SESSION['coru_flash'] = $notice;
    exit;
}

$registry = [];
$state    = coru_modules_state();

foreach (Module::all() as $slug => $manifest) {
    $entry = Module::dir($slug) . '/' . (string) ($manifest['entry'] ?? $slug . '.php');
    $roles = (array) ($state[$slug]['roles'] ?? []);
    if ($roles === []) {
        $roles = (array) ($manifest['roles'] ?? ['admin']);
    }

    $registry[] = [
        'slug'        => $slug,
        'name'        => (string) ($manifest['name'] ?? $slug),
        'version'     => (string) ($manifest['version'] ?? '0.0.0'),
        'description' => (string) ($manifest['description'] ?? ''),
        'entry'       => (string) ($manifest['entry'] ?? $slug . '.php'),
        'entry_ok'    => is_file($entry),
        'class'       => (string) ($manifest['class'] ?? ''),
        'enabled'     => (bool) ($state[$slug]['enabled'] ?? true),
        'roles'       => $roles,
        'toggled'     => (string) ($state[$slug]['toggled'] ?? ''),
        'url'         => 'pages.php',
    ];
}

usort($registry, static fn (array $a, array $b): int => strcmp($a['name'], $b['name']));

$enabledCount = count(array_filter($registry, static fn (array $m): bool => $m['enabled']));
$e = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$pageTitle = 'Модули';

require __DIR__ . '/_header.php';
?>

<section class="coru-stats">
    <div class="coru-stat"><b><?= count($registry) ?></b><span>модулей в реестре</span></div>
    <div class="coru-stat"><b><?= $enabledCount ?></b><span>включено</span></div>
    <div class="coru-stat"><b><?= count($registry) - $enabledCount ?></b><span>отключено</span></div>
    <div class="coru-stat"><b><?= count(glob(CORU_MODULES . '/*', GLOB_ONLYDIR) ?: []) ?></b><span>папок в /modules</span></div>
</section>

<section class="coru-card">
    <div class="coru-card__head">
        <h2>Реестр модулей</h2>
        <span class="coru-hint">
            Папки: <code>/modules/&lt;slug&gt;/manifest.yaml</code> ·
            состояние: <code>/adminpanel/data/modules.yaml</code>
        </span>
    </div>

    <?php if ($registry === []): ?>
        <p class="coru-empty">
            Модули не найдены. Создайте папку <code>/modules/&lt;имя&gt;</code>
            с файлом <code>manifest.yaml</code>.
        </p>
    <?php else: ?>
        <table class="coru-table">
            <thead>
                <tr>
                    <th>Модуль</th><th>Slug</th><th>Версия</th>
                    <th>Точка входа</th><th>Роли</th><th>Статус</th><th>Действия</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($registry as $module): ?>
                <tr>
                    <td>
                        <strong><?= $e($module['name']) ?></strong>
                        <?php if ($module['description'] !== ''): ?>
                            <div class="coru-hint"><?= $e($module['description']) ?></div>
                        <?php endif; ?>
                        <?php if ($module['class'] !== ''): ?>
                            <div class="coru-hint"><code><?= $e($module['class']) ?></code></div>
                        <?php endif; ?>
                    </td>

                    <td><code><?= $e($module['slug']) ?></code></td>
                    <td><?= $e($module['version']) ?></td>

                    <td>
                        <code><?= $e($module['entry']) ?></code>
                        <?php if (!$module['entry_ok']): ?>
                            <div class="coru-hint coru-hint--error">файл отсутствует</div>
                        <?php endif; ?>
                    </td>

                    <td>
                        <form method="post">
                            <?= Auth::csrfField() ?>
                            <input type="hidden" name="act" value="roles">
                            <input type="hidden" name="slug" value="<?= $e($module['slug']) ?>">

                            <div class="coru-roles">
                                <?php foreach (Auth::ROLES as $role): ?>
                                    <label class="coru-check">
                                        <input type="checkbox" name="roles[]" value="<?= $role ?>"
                                            <?= $role === 'admin' ? 'disabled checked' : '' ?>
                                            <?= in_array($role, $module['roles'], true) ? 'checked' : '' ?>>
                                        <span><?= $role ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>

                            <button class="coru-btn" type="submit">Сохранить права</button>
                        </form>
                    </td>

                    <td>
                        <?php if (!$module['entry_ok']): ?>
                            <span class="coru-role coru-role--broken">сломан</span>
                        <?php elseif ($module['enabled']): ?>
                            <span class="coru-role coru-role--editor">включён</span>
                        <?php else: ?>
                            <span class="coru-role coru-role--commentator">отключён</span>
                        <?php endif; ?>
                        <?php if ($module['toggled'] !== ''): ?>
                            <div class="coru-hint"><?= $e(substr($module['toggled'], 0, 10)) ?></div>
                        <?php endif; ?>
                    </td>

                    <td class="coru-actions">
                        <?php if ($module['slug'] === 'edit'): ?>
                            <a class="coru-btn coru-btn--primary" href="<?= $e($module['url']) ?>"
                               <?= $module['enabled'] ? '' : 'aria-disabled="true" tabindex="-1"' ?>>
                                Открыть редактор
                            </a>
                        <?php else: ?>
                            <a class="coru-btn" href="index.php?module=<?= $e($module['slug']) ?>">Запустить</a>
                        <?php endif; ?>

                        <form method="post">
                            <?= Auth::csrfField() ?>
                            <input type="hidden" name="act" value="toggle">
                            <input type="hidden" name="slug" value="<?= $e($module['slug']) ?>">
                            <button class="coru-btn <?= $module['enabled'] ? 'coru-btn--danger' : '' ?>"
                                    type="submit" <?= $module['entry_ok'] ? '' : 'disabled' ?>>
                                <?= $module['enabled'] ? 'Отключить' : 'Включить' ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<section class="coru-card">
    <h2>Как добавить модуль</h2>
    <p class="coru-hint">
        Создайте папку <code>/modules/&lt;slug&gt;/</code> и файл <code>manifest.yaml</code> —
        модуль появится в реестре автоматически.
    </p>
    <pre class="coru-code"><code>name: Мой модуль
slug: mymodule
version: 1.0.0
entry: mymodule.php
class: Coru\Modules\Mymodule\Mymodule
roles: [admin, editor]
description: Короткое описание назначения модуля.</code></pre>
</section>

<?php require __DIR__ . '/_footer.php'; ?>