<?php
declare(strict_types=1);

require dirname(__DIR__) . '/coru/bootstrap.php';
require __DIR__ . '/inc/layout.php';

use Coru\Auth;

Auth::checkCsrf();
$msg = ''; $ok = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $r = $coru->auth->register((string)($_POST['login'] ?? ''), (string)($_POST['password'] ?? ''),
        filter_var((string)($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL) ?: '', (string)($_POST['role'] ?? ''));
    $ok  = $r === true;
    $msg = $ok ? t('admin.reg_sent') : t('admin.' . $r);
}
?>
<!DOCTYPE html>
<html lang="<?= e($coru->lang->code) ?>"><head><meta charset="utf-8"><title>Coru · <?= e(t('admin.register')) ?></title>
<link rel="stylesheet" href="<?= e($coru->url('/css/coru-admin.css')) ?>"></head>
<body>
<div class="coru-auth coru-form">
  <h1><?= e(t('admin.register')) ?></h1>
  <?php if ($msg): ?><div class="coru-flash <?= $ok ? '' : 'err' ?>"><?= e($msg) ?></div><?php endif; ?>
  <?php if (!$ok): ?>
  <form method="post">
    <?= coru_csrf() ?>
    <label><?= e(t('admin.login_label')) ?></label><input type="text" name="login" required pattern="[A-Za-z0-9_\-]{3,}">
    <label><?= e(t('admin.password')) ?></label><input type="password" name="password" required minlength="6">
    <label><?= e(t('admin.email')) ?></label><input type="email" name="email">
    <label><?= e(t('admin.role')) ?></label>

<!-- выбор роли user= покупатель убрать кнопку Админка у него. -->
<select name="role">
  <option value="user">user</option>
  <option value="commentator">commentator</option>
  <option value="editor">editor</option>
</select>

    <p><button class="coru-btn"><?= e(t('admin.register')) ?></button></p>
  </form>
  <?php endif; ?>
  <p class="coru-muted"><a href="login.php"><?= e(t('admin.login')) ?></a></p>
</div>
</body></html>