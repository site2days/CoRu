<?php
declare(strict_types=1);

require dirname(__DIR__) . '/coru/bootstrap.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;
use Coru\Auth;

Auth::checkCsrf();
$setup = !$coru->auth->hasAdmin();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = (string)($_POST['login'] ?? '');
    $pass  = (string)($_POST['password'] ?? '');
    if ($setup) {
        if (strlen(Auth::cleanLogin($login)) < 3) {
            $error = t('admin.reg_bad_login');
        } elseif (strlen($pass) < 6) {
            $error = t('admin.reg_bad_pass');
        } else {
            $coru->auth->createAdmin($login, $pass, (string)($_POST['email'] ?? ''));
            $coru->auth->attempt($login, $pass);
            App::redirect($coru->url('/adminpanel/index.php'));
        }
} elseif ($coru->auth->attempt($login, $pass)) {
    $user = $coru->auth->user();

    if (($user['role'] ?? '') === 'user') {
        App::redirect($coru->url('/'));
    }

    App::redirect($coru->url(
        $coru->auth->can('editor')
            ? '/adminpanel/index.php'
            : '/adminpanel/profile.php'
    ));
}
else {
        $error = t('admin.wrong_credentials');
    }
}
$flash = App::flash();
?>
<!DOCTYPE html>
<html lang="<?= e($coru->lang->code) ?>"><head><meta charset="utf-8"><title>Coru · <?= e(t('admin.login')) ?></title>
<link rel="stylesheet" href="<?= e($coru->url('/css/coru-admin.css')) ?>"></head>
<body>
<div class="coru-auth coru-form">
  <h1><?= $setup ? e(t('admin.first_admin')) : 'CMS CoRu · ' . e(t('admin.login')) ?></h1>
  <?php if ($flash): ?><div class="coru-flash <?= e($flash[1]) ?>"><?= e($flash[0]) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="coru-flash err"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <?= coru_csrf() ?>
    <label><?= e(t('admin.login_label')) ?></label><input type="text" name="login" required autofocus>
    <label><?= e(t('admin.password')) ?></label><input type="password" name="password" required>
    <?php if ($setup): ?><label><?= e(t('admin.email')) ?></label><input type="email" name="email"><?php endif; ?>
    <p><button class="coru-btn"><?= $setup ? e(t('admin.create')) : e(t('admin.login')) ?></button></p>
  </form>
  <?php if (!$setup): ?><p class="coru-muted"><a href="registration.php"><?= e(t('admin.register')) ?></a> · <a href="<?= e($coru->url('/')) ?>">← <?= e(t('site.home')) ?></a></p><?php endif; ?>
</div>
</body></html>