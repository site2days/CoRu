<?php
declare(strict_types=1);

$coruMinRole = 'admin';

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

$cacheMessage = '';
$cacheMessageType = 'ok';
$sitemapMessage = '';
$sitemapMessageType = 'ok';
$robotsPath = CORU_ROOT . '/robots.txt';
$robotsText = is_file($robotsPath)
    ? (string)file_get_contents($robotsPath)
    : '';
$robotsMessage = '';
$robotsMessageType = 'ok';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = (string)($_POST['do'] ?? '');

    if ($action === 'cache') {
        $cacheDir = CORU_ROOT . '/coru/cache/twig';

        if (!is_dir($cacheDir)) {
            $cacheMessage = t('admin.twig_notfound');
            $cacheMessageType = 'err';
        } else {
            try {
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator(
                        $cacheDir,
                        FilesystemIterator::SKIP_DOTS
                    ),
                    RecursiveIteratorIterator::CHILD_FIRST
                );

foreach ($iterator as $entry) {
    if ($entry->isDir()) {
        if (!rmdir($entry->getPathname())) {
            throw new RuntimeException(t('admin.cache_dir_delete_failed'));
        }
    } elseif (!unlink($entry->getPathname())) {
        throw new RuntimeException(t('admin.cache_file_delete_failed'));
    }
}

                $cacheMessage = t('admin.cleaning');
            } catch (Throwable $e) {
                $cacheMessage = t('admin.errortwig_clean') . $e->getMessage();
                $cacheMessageType = 'err';
            }
        }
    } elseif ($action === 'sitemap') {
    try {
        $urls = [$coru->url('/')];

// Опубликованные страницы.
        $pages = $coru->pages->all(true);

        foreach ($pages as $page) {
            $slug = trim((string)($page['slug'] ?? ''), '/');

            if ($slug === '' || !$coru->pages->exists($slug)) {
                continue;
            }

            $urls[] = $coru->pageUrl($slug);
        }

// Категории из adminpanel/data/categories.yaml
// через уже загруженный сервис Categories.
        $categories = $coru->categories->all();
        $prettyUrls = (bool)$coru->config->get('site.pretty_urls', false);

        foreach ($categories as $category) {
            $slug = trim((string)($category['slug'] ?? ''), '/');

            if ($slug === '' || !preg_match('~^[a-zA-Z0-9_-]+$~', $slug)) {
                continue;
            }

            $urls[] = $prettyUrls
                ? $coru->url('category/' . rawurlencode($slug))
                : $coru->url('?cat=' . rawurlencode($slug));
        }

        $urls = array_values(array_unique($urls));

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<!-- Sitemap for CoRu CMS -->' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ($urls as $url) {
            $xml .= "  <url>\n";
            $xml .= '    <loc>'
                . htmlspecialchars($url, ENT_XML1 | ENT_QUOTES, 'UTF-8')
                . "</loc>\n";
            $xml .= "  </url>\n";
        }

        $xml .= "</urlset>\n";

        $sitemapPath = CORU_ROOT . '/sitemap.xml';
        $written = file_put_contents($sitemapPath, $xml, LOCK_EX);

        if ($written === false) {
            throw new RuntimeException(t('admin.notwrite_sitemap'));
        }

        $sitemapMessage = t('admin.sitemap_up', ['count' => count($urls)]);

    } catch (Throwable $e) {
	$sitemapMessage = t('admin.error_sitemap', ['error' => $e->getMessage(),]);
        $sitemapMessageType = 'err';
    }

    } elseif ($action === 'save_robots') {
    $robotsText = str_replace(
        ["\r\n", "\r"],
        "\n",
        (string)($_POST['robots_content'] ?? '')
    );

    if (file_put_contents($robotsPath, $robotsText, LOCK_EX) === false) {
        $robotsMessage = t('admin.error_setrobots');
        $robotsMessageType = 'err';
    } else {
        $robotsMessage = t('admin.robots_set');
 }

    } else {
        App::flash(t('admin.errors'), 'err');
        App::redirect('tools.php');
    }

}

coru_admin_header(t('admin.tools'));
?>

<div class="coru-card">
  <h3><?= t('admin.sistem'); ?></h3>

  <p class="coru-muted">
    PHP <?= e(PHP_VERSION) ?>
    · GD: <?= extension_loaded('gd') ? 'yes' : 'NO' ?>
    · mbstring: <?= extension_loaded('mbstring') ? 'yes' : 'NO' ?>
    · Twig:
    <?= class_exists(\Twig\Environment::class)
        ? e(\Twig\Environment::VERSION)
        : 'not installed' ?>
    · Symfony Yaml:
    <?= class_exists(\Symfony\Component\Yaml\Yaml::class)
        ? 'yes'
        : 'mini-parser' ?>
    · upload_max_filesize: <?= e((string)ini_get('upload_max_filesize')) ?>
  </p>

  <div class="coru-tools-actions">
    <form method="post" class="coru-inline">
      <?= coru_csrf() ?>
      <input type="hidden" name="do" value="cache">
      <button type="submit" class="coru-btn sec">Clear Twig cache</button>
    </form>

    <?php if ($cacheMessage !== ''): ?>
      <span class="coru-tools-message <?= e($cacheMessageType) ?>" role="status">
        <?= e($cacheMessage) ?>
      </span>
    <?php endif; ?>
  </div>

  <hr>

  <div class="coru-tools-actions">
    <form method="post" class="coru-inline">
      <?= coru_csrf() ?>
      <input type="hidden" name="do" value="sitemap">
      <button type="submit" class="coru-btn">
       <?= t('admin.set_sitemap'); ?>
      </button>
  <p><a><strong><?= t('admin.page_drafts'); ?></strong></a></p>
    </form>

    <?php if ($sitemapMessage !== ''): ?>
      <span class="coru-tools-message <?= e($sitemapMessageType) ?>" role="status">
        <?= e($sitemapMessage) ?>
      </span>
    <?php endif; ?>
  </div>

  <?php if (is_file(CORU_ROOT . '/sitemap.xml')): ?>
   <p>
      <a class="coru-btn sec"
        href="<?= e($coru->url('/sitemap.xml')) ?>"
        target="_blank"
        rel="noopener"
        ><?= t('admin.go_sitemap'); ?></a>
    </p>
  <?php endif; ?>

<!--  Редактирвоание robots.txt -->
<div class="coru-card coru-form">
  <h3><?= t('admin.сhange_robots'); ?></h3>
  <form method="post">
    <?= coru_csrf() ?>
    <input type="hidden" name="do" value="save_robots">
    <textarea
      id="coru-robots-content"
      name="robots_content"
      class="code"
      spellcheck="false"
      style="min-height:300px"
    ><?= e($robotsText) ?></textarea>

    <p>
      <button type="submit" class="coru-btn"><?= t('admin.save'); ?></button>
      <a
        class="coru-btn sec"
        href="<?= e($coru->url('/robots.txt')) ?>"
        target="_blank"
        rel="noopener"
      ><?= t('admin.open_robots'); ?></a>
    </p>

    <?php if ($robotsMessage !== ''): ?>
      <span class="coru-tools-message <?= e($robotsMessageType) ?>" role="status">
        <?= e($robotsMessage) ?>
      </span>
    <?php endif; ?>
  </form>
</div>

</div>

<style>
.coru-tools-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  margin: 12px 0;
}

.coru-tools-message {
  display: inline-block;
  padding: 7px 10px;
  border-radius: 6px;
  background: #dcfce7;
  color: #166534;
  font-size: 14px;
}

.coru-tools-message.err {
  background: #fee2e2;
  color: #991b1b;
}

.coru-card hr {
  margin: 10px 0;
  border: 0;
  border-top: 1px solid #e5e7eb;
}
</style>

<?php coru_admin_footer(); ?>