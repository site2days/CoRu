<?php
declare(strict_types=1);

$coruMinRole = 'admin';
require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

$themesDir = CORU_ROOT . '/themes';
$active    = basename((string)$coru->config->get('site.theme', 'coru-default'));
$themes    = array_map('basename', array_filter(glob($themesDir . '/*') ?: [], 'is_dir'));

/** файлы, доступные редактору: шаблоны темы + css сайта */
function coru_theme_files(string $theme): array
{
    $out = [];
    foreach (glob(CORU_ROOT . "/themes/$theme/*.twig") ?: [] as $f) {
        $out["themes/$theme/" . basename($f)] = $f;
    }
    foreach (glob(CORU_ROOT . '/css/*.css') ?: [] as $f) {
        $out['css/' . basename($f)] = $f;
    }
    return $out;
}

$theme = in_array($_GET['theme'] ?? '', $themes, true) ? (string)$_GET['theme'] : $active;
$files = coru_theme_files($theme);
$file  = isset($files[$_GET['file'] ?? '']) ? (string)$_GET['file'] : array_key_first($files);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'activate' && in_array($_POST['theme'] ?? '', $themes, true)) {
        $coru->config->set('site.theme', (string)$_POST['theme']);
        $coru->config->save();
        App::flash(t('admin.saved'));
        App::redirect('theme.php');
    }
    if ($do === 'save' && isset($files[$_POST['file'] ?? ''])) {
        file_put_contents($files[(string)$_POST['file']], str_replace("\r\n", "\n", (string)$_POST['source']), LOCK_EX);
        App::flash(t('admin.saved'));
        App::redirect('theme.php?theme=' . rawurlencode($theme) . '&file=' . rawurlencode((string)$_POST['file']));
    }
    if ($do === 'copy') {
        $new = \Coru\Pages::slugify((string)($_POST['name'] ?? ''));
        if ($new !== '' && !is_dir("$themesDir/$new")) {
            mkdir("$themesDir/$new", 0775, true);
            foreach (glob("$themesDir/$theme/*") ?: [] as $f) {
                if (is_file($f)) copy($f, "$themesDir/$new/" . basename($f));
            }
            App::flash(t('admin.saved'));
        } else {
            App::flash(t('admin.error'), 'err');
        }
        App::redirect('theme.php');
    }
}
coru_admin_header(t('admin.theme'));
?>
<div class="coru-card">
  <table class="coru-table">
    <tr><th>Theme</th><th><?= e(t('admin.status')) ?></th><th><?= e(t('admin.actions')) ?></th></tr>
    <?php foreach ($themes as $th): ?>
    <tr>
      <td><?= e($th) ?></td>
      <td><?= $th === $active ? '<span class="coru-badge on">active</span>' : '' ?></td>
      <td>
        <a class="coru-btn sm sec" href="theme.php?theme=<?= e($th) ?>"><?= e(t('admin.edit')) ?></a>
        <?php if ($th !== $active): ?>
        <form method="post" class="coru-inline"><?= coru_csrf() ?><input type="hidden" name="do" value="activate"><input type="hidden" name="theme" value="<?= e($th) ?>"><button class="coru-btn sm">Activate</button></form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <form method="post" class="coru-form coru-row" style="margin-top:12px;align-items:flex-end"><?= coru_csrf() ?><input type="hidden" name="do" value="copy">
    <div><label>New theme (copy of <?= e($theme) ?>)</label><input type="text" name="name" placeholder="my-theme" required></div>
    <div style="flex:0"><button class="coru-btn sec">+ <?= e(t('admin.create')) ?></button></div>
  </form>
</div>

<div class="coru-card coru-form">
  <form method="get" class="coru-row" style="align-items:flex-end">
    <input type="hidden" name="theme" value="<?= e($theme) ?>">
    <div><label>File</label>
      <select name="file" onchange="this.form.submit()">
        <?php foreach ($files as $k => $_): ?><option value="<?= e($k) ?>" <?= $k === $file ? 'selected' : '' ?>><?= e($k) ?></option><?php endforeach; ?>
      </select></div>
  </form>
  <?php if ($file): ?>
  <form method="post"><?= coru_csrf() ?><input type="hidden" name="do" value="save"><input type="hidden" name="file" value="<?= e($file) ?>">
    <label><?= e($file) ?></label>
    <textarea name="source" class="code" spellcheck="false"><?= e((string)file_get_contents($files[$file])) ?></textarea>
    <p><button class="coru-btn"><?= e(t('admin.save')) ?></button></p>
  </form>
  <?php endif; ?>
</div>
<?php coru_admin_footer();