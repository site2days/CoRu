<?php
declare(strict_types=1);

$coruMinRole = 'admin';
require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['slug'])) {
    $coru->modules->setEnabled(basename((string)$_POST['slug']), ($_POST['do'] ?? '') === 'on');
    App::flash(t('admin.saved'));
    App::redirect('modules.php');
}
coru_admin_header(t('admin.modules'));
?>
<table class="coru-table">
  <tr><th>slug</th><th>Name</th><th>Version</th><th>Description</th><th><?= e(t('admin.status')) ?></th><th><?= e(t('admin.actions')) ?></th></tr>
  <?php foreach ($coru->modules->all() as $m): ?>
  <tr>
    <td class="coru-muted"><?= e($m['slug']) ?></td>
    <td><?= e((string)($m['name'] ?? $m['slug'])) ?></td>
    <td><?= e((string)($m['version'] ?? '')) ?></td>
    <td><?= e((string)($m['description'] ?? '')) ?></td>
    <td><span class="coru-badge <?= $m['enabled'] ? 'on' : 'off' ?>"><?= $m['enabled'] ? 'on' : 'off' ?></span></td>
    <td>
      <?php if (!empty($m['admin'])): ?><a class="coru-btn sm sec" href="<?= e($coru->url((string)$m['admin'])) ?>">→</a><?php endif; ?>
      <form method="post" class="coru-inline"><?= coru_csrf() ?><input type="hidden" name="slug" value="<?= e($m['slug']) ?>">
        <input type="hidden" name="do" value="<?= $m['enabled'] ? 'off' : 'on' ?>"><button class="coru-btn sm <?= $m['enabled'] ? 'danger' : '' ?>"><?= $m['enabled'] ? 'Off' : 'On' ?></button></form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php coru_admin_footer();