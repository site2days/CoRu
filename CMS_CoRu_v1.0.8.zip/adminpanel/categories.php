<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'add' && trim((string)($_POST['title'] ?? '')) !== '') {
        $coru->categories->add((string)$_POST['title'], (string)($_POST['slug'] ?? ''));
    } elseif ($do === 'rename') {
        $coru->categories->rename((string)$_POST['slug'], (string)$_POST['title']);
    } elseif ($do === 'delete' && $coru->auth->can('admin')) {
        $coru->categories->remove((string)$_POST['slug']);
    }
    App::flash(t('admin.saved'));
    App::redirect('categories.php');
}
coru_admin_header(t('admin.categories'));
?>
<div class="coru-card coru-form">
  <form method="post" class="coru-row"><?= coru_csrf() ?><input type="hidden" name="do" value="add">
    <div><label><?= e(t('admin.title')) ?></label><input type="text" name="title" required></div>
    <div><label><?= e(t('admin.slug1')) ?></label>
         <input type="text" name="slug" placeholder="auto"></div>
    <div style="align-self:flex-end"><button class="coru-btn">+ <?= e(t('admin.create')) ?></button></div>
  </form>
</div>
<table class="coru-table">
  <tr><th><?= e(t('admin.slug2')) ?></th><th><?= e(t('admin.title')) ?></th><th><?= e(t('admin.pages')) ?></th><th><?= e(t('admin.actions')) ?></th></tr>
  <?php foreach ($coru->categories->all() as $c): ?>
  <tr>
    <td class="coru-muted"><?= e($c['slug']) ?></td>
    <td><form method="post" class="coru-row coru-form" style="gap:8px"><?= coru_csrf() ?><input type="hidden" name="do" value="rename"><input type="hidden" name="slug" value="<?= e($c['slug']) ?>">
        <input type="text" name="title" value="<?= e($c['title']) ?>"><button class="coru-btn sm sec" style="flex:0"><?= e(t('admin.save')) ?></button></form></td>
    <td><?= count($coru->pages->byCategory($c['slug'], false)) ?></td>
    <td><?php if ($coru->auth->can('admin')): ?><form method="post" class="coru-inline" onsubmit="return confirm('?')"><?= coru_csrf() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="slug" value="<?= e($c['slug']) ?>"><button class="coru-btn sm danger"><?= e(t('admin.delete')) ?></button></form><?php endif; ?></td>
  </tr>
  <?php endforeach; ?>
</table>
<?php coru_admin_footer();