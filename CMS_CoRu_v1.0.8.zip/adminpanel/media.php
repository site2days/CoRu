<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;
use Coru\Image;
use Coru\Pages;

$baseDir = CORU_ROOT . '/site/picture';

if (!is_dir($baseDir)) {
    mkdir($baseDir, 0775, true);
}

/**
 * Проверяет имя подпапки: только латиница, цифры, дефис и подчёркивание.
 * Пустая строка означает корень /site/picture.
 */
function coru_picture_folder(string $folder): string
{
    $folder = trim(str_replace('\\', '/', $folder), '/');

    if ($folder === '') {
        return '';
    }

    if (!preg_match('/^[a-zA-Z0-9_-]{1,64}$/', $folder)) {
        throw new InvalidArgumentException('Недопустимое имя папки.');
    }

    return $folder;
}

/**
 * Создаёт уникальное имя файла с основой до 20 символов.
 * При совпадении добавляет -2, -3 и т. д.
 */
function coru_unique_image_name(string $originalName, string $directory): string
{
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $base = Pages::slugify(pathinfo($originalName, PATHINFO_FILENAME));
    $base = rtrim(substr($base, 0, 20), '-');

    if ($base === '') {
        $base = 'image';
    }

    if (!preg_match('/^[a-z0-9]{1,10}$/', $extension)) {
        $extension = 'jpg';
    }

    $candidate = $base . '.' . $extension;
    $counter = 2;

    while (file_exists($directory . '/' . $candidate)) {
        $suffix = '-' . $counter;
        $shortBase = rtrim(substr($base, 0, max(1, 20 - strlen($suffix))), '-');
        $candidate = $shortBase . $suffix . '.' . $extension;
        $counter++;
    }

    return $candidate;
}

try {
    $currentFolder = coru_picture_folder((string)($_GET['folder'] ?? $_POST['folder'] ?? ''));
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    exit(App::e($e->getMessage()));
}

$currentDir = $currentFolder === ''
    ? $baseDir
    : $baseDir . '/' . $currentFolder;

if (!is_dir($currentDir)) {
    mkdir($currentDir, 0775, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['do'] ?? '') === 'delete') {
        $name = basename((string)($_POST['file'] ?? ''));
        $file = $currentDir . '/' . $name;

        if (is_file($file)) {
            unlink($file);
        }

        App::flash(t('admin.deleted'));
        App::redirect('media.php' . ($currentFolder !== '' ? '?folder=' . rawurlencode($currentFolder) : ''));
    }

    if (!empty($_FILES['files'])) {
        $uploaded = 0;

        foreach ($_FILES['files']['tmp_name'] as $i => $tmp) {
            if (
                ($_FILES['files']['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
                || !is_uploaded_file($tmp)
                || !Image::isImage($tmp)
            ) {
                continue;
            }

            $name = coru_unique_image_name(
                (string)($_FILES['files']['name'][$i] ?? 'image.jpg'),
                $currentDir
            );

            if (move_uploaded_file($tmp, $currentDir . '/' . $name)) {
                $uploaded++;
            }
        }

        App::flash(t('admin.saved') . " ($uploaded)");
        App::redirect('media.php' . ($currentFolder !== '' ? '?folder=' . rawurlencode($currentFolder) : ''));
    }

    App::redirect('media.php' . ($currentFolder !== '' ? '?folder=' . rawurlencode($currentFolder) : ''));
}

/* Находим папки первого уровня, например goods и avatars. */
$folders = [];
foreach (glob($baseDir . '/*', GLOB_ONLYDIR) ?: [] as $path) {
    $name = basename($path);
    if (preg_match('/^[a-zA-Z0-9_-]{1,64}$/', $name)) {
        $folders[] = $name;
    }
}
sort($folders);

/* Картинки только в выбранной папке. */
$files = array_filter(
    glob($currentDir . '/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE) ?: [],
    'is_file'
);
rsort($files);

$folderUrl = static fn(string $folder): string =>
    $coru->url('/site/picture/' . ($folder !== '' ? rawurlencode($folder) . '/' : ''));

coru_admin_header(t('admin.media'));
?>
<div class="coru-card">
  <h2>Папки изображений</h2>
  <p>
    <a class="coru-btn sm <?= $currentFolder === '' ? '' : 'sec' ?>" href="media.php">
      /site/picture/
    </a>

    <?php foreach ($folders as $folder): ?>
      <a class="coru-btn sm <?= $currentFolder === $folder ? '' : 'sec' ?>"
         href="media.php?folder=<?= e($folder) ?>">
        /site/picture/<?= e($folder) ?>/
      </a>
    <?php endforeach; ?>
  </p>

  <p class="coru-muted">
    Текущая папка: <code>/site/picture/<?= e($currentFolder !== '' ? $currentFolder . '/' : '') ?></code>
  </p>
</div>

<form method="post" enctype="multipart/form-data" class="coru-card coru-form">
  <?= coru_csrf() ?>
  <input type="hidden" name="folder" value="<?= e($currentFolder) ?>">

  <label for="coru-folder">Папка для загрузки</label>
  <select id="coru-folder" name="folder">
    <option value="" <?= $currentFolder === '' ? 'selected' : '' ?>>/site/picture/</option>
    <?php foreach ($folders as $folder): ?>
      <option value="<?= e($folder) ?>" <?= $currentFolder === $folder ? 'selected' : '' ?>>
        /site/picture/<?= e($folder) ?>/
      </option>
    <?php endforeach; ?>
    <?php if (!in_array('goods', $folders, true)): ?>
      <option value="goods" <?= $currentFolder === 'goods' ? 'selected' : '' ?>>/site/picture/goods/ — создать</option>
    <?php endif; ?>
    <?php if (!in_array('avatars', $folders, true)): ?>
      <option value="avatars" <?= $currentFolder === 'avatars' ? 'selected' : '' ?>>/site/picture/avatars/ — создать</option>
    <?php endif; ?>
  </select>

  <label for="coru-files">Картинки</label>
  <input id="coru-files" type="file" name="files[]" multiple accept="image/jpeg,image/png,image/gif,image/webp">
  <p><button class="coru-btn">Загрузить в выбранную папку</button></p>
</form>

<div class="coru-media">
<?php foreach ($files as $f):
    $name = basename($f);
    $relativePath = '/site/picture/' . ($currentFolder !== '' ? rawurlencode($currentFolder) . '/' : '') . rawurlencode($name);
    $url = $coru->url($relativePath);
?>
  <figure>
    <a href="<?= e($url) ?>" target="_blank" rel="noopener">
      <img src="<?= e($url) ?>" alt="">
    </a>
    <figcaption>
      <?= e($name) ?><br>
      <input type="text" value="<?= e($url) ?>" readonly onclick="this.select()" style="width:100%;font-size:11px">

      <form method="post" class="coru-inline" onsubmit="return confirm('Удалить файл?')">
        <?= coru_csrf() ?>
        <input type="hidden" name="do" value="delete">
        <input type="hidden" name="folder" value="<?= e($currentFolder) ?>">
        <input type="hidden" name="file" value="<?= e($name) ?>">
        <button class="coru-btn sm danger"><?= e(t('admin.delete')) ?></button>
      </form>
    </figcaption>
  </figure>
<?php endforeach; ?>
</div>
<?php coru_admin_footer(); ?>