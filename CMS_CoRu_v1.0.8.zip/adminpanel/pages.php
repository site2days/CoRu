<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete') {
    $coru->pages->delete((string)($_POST['slug'] ?? ''));
    App::flash(t('admin.deleted'));
    App::redirect('pages.php');
}

$q    = trim((string)($_GET['q'] ?? ''));
$list = $q !== '' ? $coru->pages->search($q) : $coru->pages->all();
$edit = $coru->url('/modules/edit/edit.php');

coru_admin_header(t('admin.pages'));
?>
<div class="coru-row" style="align-items:flex-end;margin-bottom:16px">
  <form method="get" class="coru-form" style="flex:3">
<!--  <label><?= e(t('admin.search')) ?></label> -->
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('admin.search')) ?>…"></form>
  <div style="text-align:right"><a class="coru-btn" href="<?= e($edit) ?>">+ <?= e(t('admin.create')) ?></a></div>
</div>
<table class="coru-table">
  <tr><th>#</th><th><?= e(t('admin.title')) ?></th><th>slug</th><th><?= e(t('admin.category')) ?></th><th><?= e(t('admin.date')) ?></th><th><?= e(t('admin.status')) ?></th><th><?= e(t('admin.actions')) ?></th></tr>
  <?php if (!$list): ?><tr><td colspan="7" class="coru-muted"><?= e(t('admin.nothing_found')) ?></td></tr><?php endif; ?>
  <?php foreach ($list as $i => $p): ?>
  <tr>
    <td><?= $i + 1 ?></td>
    <td><a href="<?= e($coru->pageUrl($p['slug'])) ?>" target="_blank"><?= e($p['title']) ?></a></td>
    <td class="coru-muted"><?= e($p['slug']) ?></td>
    <td><?= e($p['category']) ?></td>
    <td><?= e($p['date']) ?></td>
    <td><span class="coru-badge <?= $p['published'] ? 'on' : 'off' ?>"><?= e($p['published'] ? t('admin.published') : t('admin.draft')) ?></span></td>
    <td>
      <a class="coru-btn sm sec" href="<?= e($edit . '?page=' . $p['slug']) ?>"><?= e(t('admin.edit')) ?></a>
      <form method="post" class="coru-inline" onsubmit="return confirm('?')"><?= coru_csrf() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="slug" value="<?= e($p['slug']) ?>"><button class="coru-btn sm danger"><?= e(t('admin.delete')) ?></button></form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php coru_admin_footer();