<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;
use Coru\Yaml;

$langs = $coru->lang->available();
$edit = in_array($_GET['edit'] ?? '', $langs, true)
    ? (string)$_GET['edit']
    : $coru->lang->code;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = (string)($_POST['do'] ?? '');

    if ($do === 'switch' && in_array($_POST['lang'] ?? '', $langs, true)) {
        $_SESSION['coru_lang'] = (string)$_POST['lang'];

        // Язык сайта по умолчанию меняет только администратор.
        if ($coru->auth->can('admin') && isset($_POST['site_default'])) {
            $coru->config->set('site.lang', (string)$_POST['lang']);
            $coru->config->save();
        }

        App::flash(t('admin.saved'));
        App::redirect('translate.php');
    }

    // Редактирование файлов переводов доступно editor и admin.
    if ($do === 'save' && $coru->auth->can('editor')) {
        $language = (string)($_POST['lang'] ?? '');

        if (!in_array($language, $langs, true)) {
            App::flash(t('admin.error'), 'err');
            App::redirect('translate.php');
        }

        $source = str_replace(
            "\r\n",
            "\n",
            (string)($_POST['source'] ?? '')
        );

        try {
            $parsed = Yaml::parse($source);

            if ($parsed === []) {
                throw new RuntimeException('Файл перевода пуст или некорректен.');
            }

            $saved = file_put_contents(
                $coru->lang->file($language),
                $source,
                LOCK_EX
            );

            if ($saved === false) {
                throw new RuntimeException('Не удалось записать файл перевода.');
            }

            App::flash(t('admin.saved'));
        } catch (Throwable $e) {
            App::flash(t('admin.error') . ': ' . $e->getMessage(), 'err');
        }

        App::redirect('translate.php?edit=' . rawurlencode($language));
    }
}

coru_admin_header(t('admin.translate'));
?>

<div class="coru-card coru-form">
  <form method="post" class="coru-row" style="align-items:flex-end">
    <?= coru_csrf() ?>
    <input type="hidden" name="do" value="switch">

    <div>
      <label><?= e(t('admin.interfacelang')) ?></label>
      <select name="lang" required>
        <?php foreach ($langs as $language): ?>
          <option
            value="<?= e($language) ?>"
            <?= $language === $coru->lang->code ? 'selected' : '' ?>
          >
            <?= e(strtoupper($language)) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <?php if ($coru->auth->can('admin')): ?>
      <div>
        <label>
          <input type="checkbox" name="site_default">
          <?= e(t('admin.site_default_language')) ?>
        </label>
      </div>
    <?php endif; ?>

    <div style="flex:0">
      <button class="coru-btn" type="submit"><?= e(t('admin.save')) ?></button>
    </div>
  </form>
</div>

<?php if ($coru->auth->can('editor')): ?>
  <div class="coru-card coru-form">
    <p>
      <?php foreach ($langs as $language): ?>
        <a
          class="coru-btn sm <?= $language === $edit ? '' : 'sec' ?>"
          href="translate.php?edit=<?= e($language) ?>"
        ><?= e($language) ?>.yaml</a>
      <?php endforeach; ?>
    </p>

    <form method="post">
      <?= coru_csrf() ?>
      <input type="hidden" name="do" value="save">
      <input type="hidden" name="lang" value="<?= e($edit) ?>">

      <textarea name="source" class="code" spellcheck="false"><?= e(
          (string)file_get_contents($coru->lang->file($edit))
      ) ?></textarea>

      <p>
        <button class="coru-btn" type="submit"><?= e(t('admin.save')) ?></button>
      </p>
    </form>
  </div>
<?php endif; ?>

<?php coru_admin_footer(); ?>