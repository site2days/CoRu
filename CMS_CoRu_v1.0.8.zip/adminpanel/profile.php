<?php
declare(strict_types=1);

$coruMinRole = 'commentator';

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;
use Coru\Image;

$isAdmin = (($me['role'] ?? '') === 'admin');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $currentLogin = (string)($me['login'] ?? '');

    // Смена логина доступна только администратору.
    if ($isAdmin) {
        $requestedLogin = (string)($_POST['login'] ?? $currentLogin);
        $renameResult = $coru->auth->renameAdminLogin(
            $currentLogin,
            $requestedLogin
        );

        if ($renameResult !== true) {
            $messageKey = match ($renameResult) {
                'reg_bad_login' => 'admin.reg_bad_login',
                'reg_exists'    => 'admin.reg_exists',
                'access_denied' => 'admin.access_denied',
                default         => 'admin.user_not_found',
            };

            App::flash(t($messageKey), 'err');
            App::redirect('profile.php');
        }

        $currentLogin = Coru\Auth::cleanLogin($requestedLogin);
        $me['login'] = $currentLogin;
    }

    $patch = [
        'email' => filter_var(
            (string)($_POST['email'] ?? ''),
            FILTER_VALIDATE_EMAIL
        ) ?: '',
    ];

    if (($_POST['password'] ?? '') !== '') {
        if (strlen((string)$_POST['password']) < 6) {
            App::flash(t('admin.reg_bad_pass'), 'err');
            App::redirect('profile.php');
        }

        $patch['password'] = password_hash(
            (string)$_POST['password'],
            PASSWORD_DEFAULT
        );
    }

    if (
        !empty($_FILES['avatar']['tmp_name'])
        && Image::isImage($_FILES['avatar']['tmp_name'])
    ) {
        $dir = CORU_ROOT . '/site/picture/avatars';

        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            App::flash(t('admin.avatar_upload_error'), 'err');
            App::redirect('profile.php');
        }

        $dst = $dir . '/' . $currentLogin . '.jpg';

        if (Image::cropCover($_FILES['avatar']['tmp_name'], $dst, 256, 256)) {
            $patch['avatar'] = '/site/picture/avatars/' . $currentLogin . '.jpg?v=' . time();
        }
    }

    $coru->auth->updateUser($currentLogin, $patch);

    App::flash(t('admin.saved'));
    App::redirect('profile.php');
}

$u = $coru->auth->findUser((string)($me['login'] ?? '')) ?? $me;

coru_admin_header(t('admin.profile'));
?>

<form
    method="post"
    enctype="multipart/form-data"
    class="coru-card coru-form"
    style="max-width:560px"
>
  <?= coru_csrf() ?>

  <?php if (!empty($u['avatar'])): ?>
    <img
      src="<?= e($coru->url($u['avatar'])) ?>"
      alt=""
      style="width:96px;height:96px;border-radius:50%;object-fit:cover"
    >
  <?php endif; ?>

  <label><?= e(t('admin.loginadm')) ?></label>
  <input
    type="text"
    name="login"
    value="<?= e((string)($u['login'] ?? '')) ?>"
    <?= $isAdmin ? 'required minlength="3" autocomplete="username"' : 'disabled' ?>
  >

  <label><?= e(t('admin.role')) ?></label>
  <input
    type="text"
    value="<?= e((string)($u['role'] ?? '')) ?>"
    disabled
  >

  <label><?= e(t('admin.email')) ?></label>
  <input
    type="email"
    name="email"
    value="<?= e((string)($u['email'] ?? '')) ?>"
  >

  <label><?= e(t('admin.password_adm')) ?></label>
  <input
    type="password"
    name="password"
    autocomplete="new-password"
  >

  <label>Avatar (jpg/png/gif/webp → 256×256)</label>
  <input type="file" name="avatar" accept="image/*">

  <p>
    <button class="coru-btn" type="submit">
      <?= e(t('admin.save')) ?>
    </button>
  </p>
</form>

<?php coru_admin_footer(); ?>