<?php
declare(strict_types=1);

$coruMinRole = 'admin';

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;
use Coru\Auth;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = (string)($_POST['do'] ?? '');
    $login = Auth::cleanLogin((string)($_POST['login'] ?? ''));

    switch ($do) {
        case 'approve':
            $coru->auth->updateUser($login, ['status' => 'active']);
            break;

        case 'block':
            $coru->auth->updateUser($login, ['status' => 'blocked']);
            break;

        case 'role':
            $role = (string)($_POST['role'] ?? '');

            if (in_array($role, ['editor', 'commentator', 'user'], true)) {
                $coru->auth->updateUser($login, ['role' => $role]);
            } else {
                App::flash('Недопустимая роль.', 'err');
                App::redirect('users.php');
            }
            break;

        case 'delete':
            $coru->auth->deleteUser($login);
            break;

        default:
            App::flash('Неизвестное действие.', 'err');
            App::redirect('users.php');
    }

    App::flash(t('admin.saved'));
    App::redirect('users.php');
}

$users = $coru->auth->users();

usort(
    $users,
    static fn(array $a, array $b): int =>
        strcmp((string)($a['status'] ?? ''), (string)($b['status'] ?? ''))
);

coru_admin_header(e(t('admin.usrs')));
?>

<div class="coru-card">
<!-- <h3><?= e(t('admin.users_total')) ?> (/users)</h3> -->

  <table class="coru-table">
    <thead>
      <tr>
        <th><?= e(t('admin.login_label')) ?></th>
        <th><?= e(t('admin.email')) ?></th>
        <th><?= e(t('admin.role')) ?></th>
        <th><?= e(t('admin.status')) ?></th>
        <th><?= e(t('admin.actions')) ?></th>
      </tr>
    </thead>

    <tbody>
      <?php if (!$users): ?>
        <tr>
          <td colspan="5" class="coru-muted">
            <?= e(t('admin.nothing_found')) ?>
          </td>
        </tr>
      <?php endif; ?>

      <?php foreach ($users as $user): ?>
        <?php $status = (string)($user['status'] ?? 'pending'); ?>

        <tr<?= $status === 'pending' ? ' id="pending"' : '' ?>>
          <td><?= e((string)($user['login'] ?? '')) ?></td>
          <td><?= e((string)($user['email'] ?? '')) ?></td>

          <td>
            <form method="post" class="coru-inline">
              <?= coru_csrf() ?>
              <input type="hidden" name="do" value="role">
              <input
                type="hidden"
                name="login"
                value="<?= e((string)($user['login'] ?? '')) ?>"
              >

              <select name="role" onchange="this.form.submit()">
                <?php foreach (['editor', 'commentator', 'user'] as $role): ?>
                  <option
                    value="<?= e($role) ?>"
                    <?= ($user['role'] ?? '') === $role ? 'selected' : '' ?>
                  >
                    <?= e($role) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </form>
          </td>

          <td>
            <span class="coru-badge <?= $status === 'active' ? 'on' : ($status === 'blocked' ? 'off' : '') ?>">
              <?= e($status) ?>
            </span>
          </td>

          <td>
            <?php if ($status !== 'active'): ?>
              <form method="post" class="coru-inline">
                <?= coru_csrf() ?>
                <input type="hidden" name="do" value="approve">
                <input
                  type="hidden"
                  name="login"
                  value="<?= e((string)($user['login'] ?? '')) ?>"
                >
                <button type="submit" class="coru-btn sm">Подтвердить</button>
              </form>
            <?php endif; ?>

            <?php if ($status === 'active'): ?>
              <form method="post" class="coru-inline">
                <?= coru_csrf() ?>
                <input type="hidden" name="do" value="block">
                <input type="hidden" name="login" value="<?= e((string)($user['login'] ?? '')) ?>">
                <button type="submit" class="coru-btn sm sec">Заблокировать</button>
              </form>
            <?php endif; ?>

            <form
              method="post"
              class="coru-inline"
              onsubmit="return confirm('Удалить пользователя?')"
            >
              <?= coru_csrf() ?>
              <input type="hidden" name="do" value="delete">
              <input
                type="hidden"
                name="login"
                value="<?= e((string)($user['login'] ?? '')) ?>"
              >
              <button type="submit" class="coru-btn sm danger">
                <?= e(t('admin.delete')) ?>
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="coru-card">
  <h3><?= e(t('admin.admin_site')) ?> ( set to adm.yaml )</h3>
  <ul>
    <?php foreach ($coru->auth->admins() as $admin): ?>
<li>
    <?= e((string)($admin['login'] ?? '')) ?>
    <span class="coru-muted">
      <?= e((string)($admin['email'] ?? '')) ?>
      from <?php 
          $created = ($admin['created'] ?? '');
          if ($created) {
              $dt = new DateTime($created);
              echo e($dt->format('d.m.Y')); 
          }
      ?>
    </span>
</li>
    <?php endforeach; ?>
  </ul>
</div>

<?php coru_admin_footer(); ?>