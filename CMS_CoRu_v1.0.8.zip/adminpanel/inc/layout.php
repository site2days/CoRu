<?php
declare(strict_types=1);

use Coru\App;
use Coru\Auth;

function e(?string $s): string
{
    return App::e($s);
}

function t(string $key, array $replacements = []): string
{
    return App::instance()->t($key, $replacements);
}

function coru_icon(string $name): string
{
    static $paths = [
        'home'   => '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z"/>',
        'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'usrs'   => '<circle cx="8" cy="8" r="3.5"/><circle cx="18" cy="8" r="3.5"/><path d="M2 20a6 6 0 0 1 12 0"/><path d="M12 20a6 6 0 0 1 12 0"/>',
        'tag'    => '<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="8" cy="8" r="1.5"/>',
        'puzzle' => '<rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="8" rx="1"/><rect x="3" y="13" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/>',
        'cog'    => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
        'file'   => '<path d="M6 2h8l4 4v16H6z"/><path d="M14 2v4h4"/><path d="M9 13h6M9 17h6"/>',
        'image'  => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
        'brush'  => '<path d="M20 4l-9 9"/><path d="M11 13c-3 0-4 2-4 4s-2 3-4 3c3 1 7 0 8-3 1-2 0-4 0-4z"/>',
        'globe'  => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
        'wrench' => '<path d="M14 7a4 4 0 0 0 5 5l-9 9-3-3 9-9z"/><path d="M14 7l3 3"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
        'menu'   => '<path d="M3 6h18M3 12h18M3 18h18"/>',
        'cart'   => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
	'lang'   => '<path d="M4 21V4"/><path d="M5 5c5-4 9 4 15 0v10c-6 4-10-4-15 0"/>',
    ];

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
        . ($paths[$name] ?? '')
        . '</svg>';
}

function coru_admin_header(string $title): void
{
    global $coru, $me;

    $adminBase = '/adminpanel/';
    $adminUrl = $coru->url($adminBase);

    /*
     * Последнее поле — разрешение меню.
     * Для роли user пункт показывается только при наличии permission
     * с соответствующим именем в user YAML.
     */
    $menu = [
        ['profile.php',               'admin.profile',    'user',   'admin.profile'],
        ['/modules/goods/orders.php', 'goods.orders',     'cart',   'goods.orders'],
        ['pages.php',                 'admin.pages',      'file',   'admin.pages'],
        ['categories.php',            'admin.categories', 'tag',    'admin.categories'],
	['users.php',                 'admin.usrs',       'usrs',   'admin.usrs'],
        ['media.php',                 'admin.media',      'image',  'admin.media'],
        ['modules.php',               'admin.modules',    'puzzle', 'admin.modules'],
        ['theme.php',                 'admin.theme',      'brush',  'admin.theme'],
        ['translate.php',             'admin.translate',  'globe',  'admin.translate'],
 	['lang.php',                  'admin.lang',       'lang',   'admin.lang'],
        ['tools.php',                 'admin.tools',      'wrench', 'admin.tools'],
        ['settings.php',              'admin.settings',   'cog',    'admin.settings'],
    ];

    $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $currentPath = parse_url($scriptName, PHP_URL_PATH) ?: '';
    $currentPath = rtrim($currentPath, '/') ?: '/';
    $dashboardPath = rtrim($adminBase, '/') . '/index.php';
    $flash = App::flash();
    ?>
<!DOCTYPE html>
<html lang="<?= e($coru->lang->code) ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> · Coru</title>
  <link rel="stylesheet" href="<?= e($coru->url('/css/coru-admin.css')) ?>">
</head>
<body>
<aside class="coru-side">
  <a
    class="coru-logo <?= $currentPath === $dashboardPath ? 'active' : '' ?>"
    href="<?= e($adminUrl . 'index.php') ?>"
    title="<?= e(t('admin.dashboard')) ?>"
  >
    <b>C</b><span class="label">Coru</span>
  </a>

  <!-- Кнопка первой строкой бокового меню, сразу под логотипом -->
  <button
    type="button"
    class="coru-toggle"
    id="coruToggle"
    aria-label="menu"
    aria-expanded="false"
  >
    <?= coru_icon('menu') ?>
    <span class="label"><?= e(t('admin.menu')) ?></span>
  </button>

  <?php foreach ($menu as [$path, $translationKey, $icon, $permission]): ?>
    <?php
      if (!$coru->auth->hasPermission($permission)) {
          continue;
      }

      $isAbsolutePath = str_starts_with($path, '/');
      $href = $isAbsolutePath
          ? $coru->url($path)
          : $adminUrl . $path;

      $menuPath = $isAbsolutePath
          ? $path
          : rtrim($adminBase, '/') . '/' . $path;

      $menuPath = rtrim($menuPath, '/') ?: '/';
      $isActive = $currentPath === $menuPath;
    ?>
    <a
      href="<?= e($href) ?>"
      class="<?= $isActive ? 'active' : '' ?>"
      title="<?= e(t($translationKey)) ?>"
    >
      <?= coru_icon($icon) ?>
      <span class="label"><?= e(t($translationKey)) ?></span>
    </a>
  <?php endforeach; ?>

  <div class="coru-side-spacer"></div>

  <a href="<?= e($adminUrl . 'logout.php') ?>" title="<?= e(t('admin.logout')) ?>">
    <?= coru_icon('logout') ?>
    <span class="label"><?= e(t('admin.logout')) ?></span>
  </a>
</aside>

<div class="coru-main">
  <header class="coru-top">
    <h1><?= e($title) ?></h1>

    <div class="coru-me">
      <?php if (!empty($me['avatar'])): ?>
        <img src="<?= e($coru->url($me['avatar'])) ?>" alt="">
      <?php endif; ?>
      <span><?= e($me['login'] ?? '') ?> · <?= e($me['role'] ?? '') ?></span>
    </div>
  </header>

  <?php if ($flash): ?>
    <div class="coru-flash <?= e($flash[1] ?? '') ?>">
      <?= e($flash[0] ?? '') ?>
    </div>
  <?php endif; ?>

  <section class="coru-content">
<?php
}

function coru_admin_footer(): void
{
    ?>
  </section>
</div>

<script>
(function () {
  var body = document.body;
  var key = 'coru_sb_open';
  var toggle = document.getElementById('coruToggle');

  function updateToggle() {
    if (toggle) {
      toggle.setAttribute(
        'aria-expanded',
        body.classList.contains('sb-open') ? 'true' : 'false'
      );
    }
  }

  if (localStorage.getItem(key) === '1') {
    body.classList.add('sb-open');
  }
  updateToggle();

  if (toggle) {
    toggle.addEventListener('click', function () {
      body.classList.toggle('sb-open');
      localStorage.setItem(
        key,
        body.classList.contains('sb-open') ? '1' : '0'
      );
      updateToggle();
    });
  }
})();
</script>
</body>
</html>
<?php
}

function coru_csrf(): string
{
    return Auth::csrfField();
}