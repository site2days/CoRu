<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/coru/bootstrap.php';

use Coru\Auth;

Auth::checkCsrf();
$coru->auth->requireRole($coruMinRole ?? 'editor');
$me = $coru->auth->user();