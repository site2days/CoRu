<?php
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

$pages   = $coru->pages->all();
$pub     = count(array_filter($pages, fn($p) => $p['published']));
$mods    = $coru->modules->all();
$modsOn  = count(array_filter($mods, fn($m) => $m['enabled']));
$users   = $coru->auth->users();
$pending = count(array_filter(
    $users,
    fn($u) => ($u['status'] ?? '') === 'pending'
));

$size = 0;
$siteDir = CORU_ROOT . '/site';

if (is_dir($siteDir)) {
    foreach (
        new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($siteDir, FilesystemIterator::SKIP_DOTS)
        ) as $file
    ) {
        $size += $file->getSize();
    }
}

coru_admin_header(t('admin.dashboard'));
?>

<!-- Go CHAT  <h2><?= e(t('admin.stats')) ?></h2> -->
<div class="dashboard-heading">
  <h2><?= e(t('admin.stats')) ?></h2>
  <a class="dashboard-chat-link"
     href="<?= e($coru->url('/?p=chat')) ?>">
     <?= e(t('admin.toсhat')) ?>
  </a>
</div>

<div class="coru-cards">
  <div class="coru-stat">
    <b><?= count($pages) ?></b>
    <span><?= e(t('admin.pages_total')) ?></span>
  </div>

  <div class="coru-stat">
    <b><?= $pub ?></b>
    <span><?= e(t('admin.pages_published')) ?></span>
  </div>

  <a class="coru-stat coru-stat-link"
     href="<?= e($coru->url('/adminpanel/categories.php')) ?>">
    <b><?= count($coru->categories->all()) ?></b>
    <span><?= e(t('admin.categories')) ?></span>
  </a>

  <a class="coru-stat coru-stat-link"
     href="<?= e($coru->url('/adminpanel/modules.php')) ?>">
    <b><?= $modsOn ?> / <?= count($mods) ?></b>
    <span><?= e(t('admin.modules_enabled')) ?></span>
  </a>

  <a class="coru-stat coru-stat-link"
     href="<?= e($coru->url('/adminpanel/users.php')) ?>">
    <b><?= count($users) + count($coru->auth->admins()) ?></b>
    <span><?= e(t('admin.users_total')) ?></span>
  </a>

  <a class="coru-stat coru-stat-link"
     href="<?= e($coru->url('/adminpanel/users.php#pending')) ?>">
    <b><?= $pending ?></b>
    <span><?= e(t('admin.users_pending')) ?> →</span>
  </a>

  <div class="coru-stat">
    <b><?= round($size / 1048576, 1) ?> MB</b>
    <span><?= e(t('admin.site_size')) ?></span>
  </div>

  <div class="coru-stat">
    <b><?= PHP_VERSION ?></b>
    <span>
      PHP · Twig
      <?= class_exists(\Twig\Environment::class) ? \Twig\Environment::VERSION : '—' ?>
      · Coru <?= CORU_VERSION ?>
    </span>
  </div>
</div>

<div class="coru-card">
  <h3><?= e(t('admin.pages')) ?></h3>

  <table class="coru-table">
    <tr>
      <th><?= e(t('admin.title')) ?></th>
      <th><?= e(t('admin.category')) ?></th>
      <th><?= e(t('admin.date')) ?></th>
      <th></th>
    </tr>

    <?php foreach (array_slice($pages, 0, 8) as $page): ?>
      <tr>
        <td><?= e($page['title']) ?></td>
        <td><?= e($page['category']) ?></td>
        <td><?= e($page['date']) ?></td>
        <td>
          <a
            class="coru-btn sm sec"
            href="<?= e($coru->url('/modules/edit/edit.php?page=' . $page['slug'])) ?>"
          ><?= e(t('admin.edit')) ?></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<style>
a.coru-stat-link {
  color: inherit;
  text-decoration: none;
}

a.coru-stat-link:hover {
  text-decoration: none;
  filter: brightness(.97);
}
</style>

<?php coru_admin_footer(); ?>