<?php
declare(strict_types=1);

$coruMinRole = 'admin';
require __DIR__ . '/inc/boot.php';
require __DIR__ . '/inc/layout.php';

use Coru\App;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $c = $coru->config;
    $c->set('site.title',           trim((string)$_POST['title']));
    $c->set('site.description',     trim((string)$_POST['description']));
    $c->set('site.keywords',        trim((string)$_POST['keywords']));
    $c->set('site.base_url',        rtrim(trim((string)$_POST['base_url']), '/'));
    $c->set('site.use_global_meta', isset($_POST['use_global_meta']));
    $c->set('site.pretty_urls',     isset($_POST['pretty_urls']));
    $c->save();
    App::flash(t('admin.saved'));
    App::redirect('settings.php');
}
$s = $coru->config->get('site', []);
coru_admin_header(t('admin.settings'));
?>
<form method="post" class="coru-card coru-form" style="max-width:760px"><?= coru_csrf() ?>
  <label><?= t('admin.site_title'); ?></label>
	<input type="text" name="title" value="<?= e($s['title'] ?? '') ?>">
  <label><?= t('admin.default_description'); ?></label>
	<textarea name="description"><?= e($s['description'] ?? '') ?></textarea>
  <label><?= t('admin.default_keywords'); ?></label>
	<input type="text" name="keywords" value="<?= e($s['keywords'] ?? '') ?>">
  <label><?= t('admin.base_url'); ?></label>
	<input type="text" name="base_url" value="<?= e($s['base_url'] ?? '') ?>" placeholder="https://example.com">
  <p><label><input type="checkbox" name="use_global_meta" <?= !empty($s['use_global_meta']) ? 'checked' : '' ?>> <?= t('admin.set_description_keywords'); ?></label>
  </p>
  <p><label><input type="checkbox" name="pretty_urls" <?= !empty($s['pretty_urls']) ? 'checked' : '' ?>><?= t('admin.set_slus'); ?></label>
  </p>
  <button class="coru-btn"><?= e(t('admin.save')) ?></button>
</form>
<?php coru_admin_footer();